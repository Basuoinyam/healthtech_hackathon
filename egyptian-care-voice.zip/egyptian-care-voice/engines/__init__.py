"""Speech synthesis engine adapters."""
from engines.base import EngineError, EngineUnavailableError, TTSEngine
from engines.registry import get_engine, list_engines

__all__ = ["EngineError", "EngineUnavailableError", "TTSEngine", "get_engine", "list_engines"]
