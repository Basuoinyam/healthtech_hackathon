"""Common interface and errors for speech synthesis engines."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np


class EngineError(RuntimeError):
    """Base error raised by an engine adapter."""


class EngineUnavailableError(EngineError):
    """Raised when an optional engine dependency is not installed."""


class TTSEngine(ABC):
    """Small adapter interface. Audio is mono float32 plus its sample rate."""

    name: str

    @abstractmethod
    def list_voices(self) -> list[str]:
        """Return available voice identifiers."""

    @abstractmethod
    def synthesize(self, text: str, voice: str | None = None, **params: Any) -> tuple[np.ndarray, int]:
        """Return normalized mono audio and the sample rate."""

    def supports(self, feature: str) -> bool:
        """Return whether this adapter natively supports a generation feature."""
        return False
