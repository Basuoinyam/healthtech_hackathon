"""Install checks for optional adapters whose model packages are not core dependencies."""
from __future__ import annotations

import importlib
from typing import Any

import numpy as np

from engines.base import EngineError, EngineUnavailableError, TTSEngine


class OptionalPackageEngine(TTSEngine):
    """Provide an actionable error without importing large optional runtimes eagerly."""

    def __init__(self, name: str, module_name: str, install_hint: str) -> None:
        self.name = name
        self.module_name = module_name
        self.install_hint = install_hint

    def _require_package(self):
        try:
            return importlib.import_module(self.module_name)
        except ImportError as exc:
            raise EngineUnavailableError(
                f"The {self.name} engine package is missing. Install it with: {self.install_hint}"
            ) from exc

    def list_voices(self) -> list[str]:
        self._require_package()
        raise EngineError(
            f"The {self.name} package is installed, but this project's adapter does not expose voice listing yet."
        )

    def synthesize(self, text: str, voice: str | None = None, **params: Any) -> tuple[np.ndarray, int]:
        self._require_package()
        raise EngineError(
            f"The {self.name} synthesis adapter is not implemented yet; use cairo or mock."
        )
