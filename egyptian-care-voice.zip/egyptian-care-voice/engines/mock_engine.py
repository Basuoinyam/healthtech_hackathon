"""Offline deterministic engine for tests and demos."""
from __future__ import annotations

import hashlib
from typing import Any

import numpy as np

from engines.base import TTSEngine


class MockEngine(TTSEngine):
    name = "mock"
    sample_rate = 22050
    _voices = ["mock_female", "mock_male"]

    def list_voices(self) -> list[str]:
        return self._voices.copy()

    def supports(self, feature: str) -> bool:
        return feature == "speed"

    def synthesize(self, text: str, voice: str | None = None, **params: Any) -> tuple[np.ndarray, int]:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non-empty string")
        selected = voice or self._voices[0]
        if selected not in self._voices:
            raise ValueError(f"Unknown mock voice {selected!r}; choose from {', '.join(self._voices)}")
        speed = float(params.get("speed", 1.0))
        if not 0.5 <= speed <= 1.5:
            raise ValueError("speed must be between 0.5 and 1.5")
        # Keep test clips short while making duration proportional to text length.
        duration = max(0.25, min(30.0, len(text.strip()) / (14.0 * speed)))
        count = max(1, int(self.sample_rate * duration))
        seed_text = f"{text}\0{selected}".encode("utf-8")
        digest = hashlib.sha256(seed_text).digest()
        frequency = 180.0 + int.from_bytes(digest[:2], "big") % 180
        phase = int.from_bytes(digest[2:4], "big") / 65535.0 * 6.283185307179586
        time = np.arange(count, dtype=np.float32) / self.sample_rate
        wave = 0.08 * np.sin(2.0 * np.pi * frequency * time + phase)
        return wave.astype(np.float32, copy=False), self.sample_rate
