"""Lazy adapter for Cairo-TTS; model loading occurs only on synthesis."""
from __future__ import annotations

import importlib
import tempfile
from pathlib import Path
from typing import Any

import numpy as np

from engines.base import EngineError, EngineUnavailableError, TTSEngine


class CairoEngine(TTSEngine):
    name = "cairo"
    # Cairo-TTS 0.2.0 README voice IDs; using this list does not download weights.
    _voices = [
        "mohamed", "ahmed", "ali", "omar", "youssef", "mostafa", "karim",
        "hassan", "tarek", "yehia", "sara", "mariam", "nour", "fatma",
        "heba", "yasmin", "mona", "rana", "dina", "malak",
    ]

    def __init__(self, model_id: str = "mohammedaly22/Cairo-TTS", device: str = "cpu") -> None:
        self.model_id = model_id
        self.device = device
        self._model = None

    def list_voices(self) -> list[str]:
        try:
            importlib.import_module("cairo_tts")
        except ImportError as exc:
            raise EngineUnavailableError(
                "Cairo-TTS is not installed. Install it with: pip install cairo-tts"
            ) from exc
        return self._voices.copy()

    def supports(self, feature: str) -> bool:
        # Cairo's documented API does not expose speed or emotion controls.
        return feature == "cloning"

    def _load(self):
        if self._model is None:
            try:
                module = importlib.import_module("cairo_tts")
            except ImportError as exc:
                raise EngineUnavailableError(
                    "Cairo-TTS is not installed. Install it with: pip install cairo-tts"
                ) from exc
            try:
                self._model = module.CairoTTS.from_pretrained(self.model_id, device=self.device)
            except Exception as exc:
                raise EngineError(f"Could not load Cairo-TTS model {self.model_id!r}: {exc}") from exc
        return self._model

    def synthesize(self, text: str, voice: str | None = None, **params: Any) -> tuple[np.ndarray, int]:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non-empty string")
        selected = voice or "tarek"
        if selected not in self._voices:
            raise ValueError(f"Unknown Cairo voice {selected!r}; run 'python main.py voices --engine cairo'")
        if float(params.get("speed", 1.0)) != 1.0 or params.get("emotion") not in (None, ""):
            raise EngineError("Cairo-TTS does not natively support speed or emotion; apply speed in audio post-processing")
        model = self._load()
        try:
            import soundfile as sf
        except ImportError as exc:
            raise EngineUnavailableError("soundfile is required. Install it with: pip install soundfile") from exc
        with tempfile.TemporaryDirectory(prefix="egyptian-care-voice-") as tmp:
            output_path = Path(tmp) / "speech.wav"
            try:
                model.save(text, str(output_path), voice=selected)
                audio, sample_rate = sf.read(output_path, dtype="float32", always_2d=False)
            except Exception as exc:
                raise EngineError(f"Cairo-TTS synthesis failed: {exc}") from exc
        if audio.ndim == 2:
            audio = audio.mean(axis=1)
        return np.asarray(audio, dtype=np.float32), int(sample_rate)
