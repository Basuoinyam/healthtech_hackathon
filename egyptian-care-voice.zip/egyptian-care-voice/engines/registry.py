"""Lazy engine registry."""
from __future__ import annotations

from engines.base import EngineError
from engines.cairo_engine import CairoEngine
from engines.mock_engine import MockEngine
from engines.optional import OptionalPackageEngine
from engines.voicetut_engine import VoiceTutEngine

_ENGINE_NAMES = ("cairo", "mock", "voicetut", "namaa", "nile-xtts")
_ENGINE_FACTORIES = {
    "cairo": CairoEngine,
    "mock": MockEngine,
    "voicetut": VoiceTutEngine,
    "namaa": lambda: OptionalPackageEngine(
        "namaa", "chatterbox",
        "pip install chatterbox-tts",
    ),
    "nile-xtts": lambda: OptionalPackageEngine(
        "nile-xtts", "TTS",
        "pip install coqui-tts",
    ),
}


def get_engine(name: str, config: dict | None = None):
    """Construct an engine by its registered name."""
    key = name.strip().lower()
    try:
        if key == "voicetut" and config:
            options = config.get("voicetut") or {}
            return VoiceTutEngine(
                model_id=options.get("repo_id", "mohammedaly22/VoiceTut-TTS"),
                voices_dir=options.get("voices_dir", "voices"),
                device=options.get("device"),
                dtype=options.get("dtype"),
            )
        return _ENGINE_FACTORIES[key]()
    except KeyError as exc:
        available = ", ".join(_ENGINE_NAMES)
        raise EngineError(f"Unknown engine {name!r}. Available engines: {available}") from exc


def list_engines() -> list[str]:
    return list(_ENGINE_NAMES)
