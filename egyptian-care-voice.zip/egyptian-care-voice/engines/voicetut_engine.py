"""Lazy adapter for VoiceTut-TTS, the Egyptian Arabic OmniVoice fine-tune.

API source (verified against the published voicetut-tts 0.1.1 package):
https://pypi.org/project/voicetut-tts/ and https://github.com/MohammedAly22/VoiceTuT-TTS
``VoiceTutTTS.from_pretrained(repo, device=, dtype=)`` then
``synthesize(text, speaker=|ref_audio=+ref_text=, language="arz", speed=, ...) -> np.ndarray``.
"""
from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

import numpy as np

from engines.base import EngineError, EngineUnavailableError, TTSEngine

# Built-in speakers reported by the loaded VoiceTut-TTS model.
BUILTIN_SPEAKERS: dict[str, str] = {
    "Ahmed": "male", "Ali": "male", "Hassan": "male", "Karim": "male", "Mahmoud": "male",
    "Mohammed": "male", "Mostafa": "male", "Ramy": "male", "Shaker": "male", "Tareq": "male",
    "Yehia": "male", "Youssef": "male",
    "Hadeer": "female", "Hanan": "female", "Mariam": "female", "Rana": "female",
    "Sarah": "female", "Yasmin": "female", "Yara": "female",
}
# Stable project-level names mapped to built-in speakers.
DEFAULT_ALIASES: dict[str, str] = {
    "egyptian_male_1": "Ahmed",
    "egyptian_female_1": "Hanan",
}


class VoiceTutEngine(TTSEngine):
    name = "voicetut"

    def __init__(self, model_id: str = "mohammedaly22/VoiceTut-TTS",
                 voices_dir: str | Path = "voices", device: str | None = None,
                 dtype: str | None = None) -> None:
        self.model_id = model_id
        self.voices_dir = Path(voices_dir)
        self.device = device
        self.dtype = dtype
        self._model = None

    def _custom_voices(self) -> list[str]:
        if self.voices_dir.is_dir():
            return sorted(p.stem for p in self.voices_dir.glob("*.wav") if p.is_file())
        return []

    def list_voices(self) -> list[str]:
        """Project aliases first (male default), then built-in speakers, then cloned voices."""
        return list(DEFAULT_ALIASES) + list(BUILTIN_SPEAKERS) + self._custom_voices()

    def supports(self, feature: str) -> bool:
        # speed is a native generation parameter; cloning works from voices/<name>.wav
        return feature in {"speed", "cloning"}

    def _load(self):
        if self._model is None:
            try:
                module = importlib.import_module("voicetut_tts")
            except ImportError as exc:
                raise EngineUnavailableError(
                    "VoiceTut-TTS is not installed. Install torch from pytorch.org, then run: "
                    "pip install -r requirements-engines.txt "
                    "(it installs OmniVoice from GitHub and voicetut-tts)."
                ) from exc
            try:
                device, dtype = self.device, self.dtype
                if device is None or dtype is None:
                    try:
                        import torch
                        cuda = torch.cuda.is_available()
                    except ImportError:  # the real package needs torch; fall back to CPU defaults
                        cuda = False
                    device = device or ("cuda" if cuda else "cpu")
                    dtype = dtype or ("float16" if device.startswith("cuda") else "float32")
                self._model = module.VoiceTutTTS.from_pretrained(self.model_id, device=device, dtype=dtype)
            except Exception as exc:
                raise EngineError(f"Could not load VoiceTut-TTS model {self.model_id!r}: {exc}") from exc
        return self._model

    def synthesize(self, text: str, voice: str | None = None, speed: float = 1.0,
                   emotion: str | None = None, **kwargs: Any) -> tuple[np.ndarray, int]:
        if not isinstance(text, str) or not text.strip():
            raise ValueError("text must be a non-empty string")
        available = self.list_voices()
        selected = voice or available[0]
        if selected not in available:
            raise ValueError(f"Unknown VoiceTut voice {selected!r}; run 'python main.py voices --engine voicetut'")
        if emotion not in (None, ""):
            raise EngineError("VoiceTut-TTS does not expose an emotion control")

        model = self._load()
        options: dict[str, Any] = dict(kwargs)
        options["speed"] = float(speed)
        options["language"] = options.pop("language", "arz")
        ref_audio = self.voices_dir / f"{selected}.wav"
        if ref_audio.is_file():
            options["ref_audio"] = str(ref_audio)
            transcript = ref_audio.with_suffix(".txt")  # optional reference transcript
            if transcript.is_file():
                ref_text = transcript.read_text(encoding="utf-8").strip()
                if ref_text:
                    options["ref_text"] = ref_text
        else:
            options["speaker"] = DEFAULT_ALIASES.get(selected, selected)
        try:
            audio = model.synthesize(text, **options)
            sample_rate = int(model.sampling_rate)
        except Exception as exc:
            raise EngineError(f"VoiceTut-TTS synthesis failed: {exc}") from exc

        waveform = np.asarray(audio, dtype=np.float32)
        if waveform.ndim == 2:
            waveform = waveform.mean(axis=1 if waveform.shape[1] <= 8 else 0)
        waveform = waveform.reshape(-1)
        if waveform.size == 0:
            raise EngineError("VoiceTut-TTS returned empty audio")
        peak = float(np.max(np.abs(waveform)))
        if peak > 1.0:
            waveform = waveform / peak
        return np.clip(waveform, -1.0, 1.0).astype(np.float32, copy=False), sample_rate
