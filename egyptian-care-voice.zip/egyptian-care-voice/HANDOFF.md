# HANDOFF: egyptian-care-voice

## Goal
Build the full project described in `egyptian_tts_robot_prompt.md` (attach that file too; it is the source of truth). Follow its 8-phase plan in order and do not skip a phase's completion criterion.

## User preferences (must follow)
- All code, comments, docstrings and print/CLI messages in ENGLISH. Explanations to the user in Egyptian Arabic.
- Exception: Arabic content that is the product itself stays Arabic: validation error text (spec demands Arabic), phrases.json, escalation line, blocked_phrases.json reasons, شرح_المشروع.md.
- Free/open-source only, no paid APIs.
- After each phase: run tests, update شرح_المشروع.md (incl. changelog) and HANDOFF.md, tell the user what finished.
- Do not guess TTS library APIs: read each README (GitHub/HF) and record the source in شرح_المشروع.md.
- Do not start a phase until the previous phase's completion criterion is met.
- If the run ends early, update this file so the next model can continue the same way.

## Status
- **Phases 0 to 8 are implemented.** VoiceTut-TTS is the default engine (`default_engine: voicetut` in config.yaml).
- VERIFIED with real pytest on 2026-11-21: `python -m pytest -q` -> **288 passed, 1 skipped**. The suite is green.
- The portable `imageio-ffmpeg` package is now accepted as an ffmpeg fallback, so MP3 export works without a system binary or a project-root `ffmpeg.exe` when that package is installed.
- Three mock rendered sample pairs exist in `outputs/`: `before_session_anxious_mock`, `bad_day_mock`, and `milestone_mock`.
- Real VoiceTut synthesis was verified on the user's NVIDIA Quadro P2000. Tested environment: PyTorch `2.7.1+cu126`, torchaudio `2.7.1+cu126`, CUDA 12.6, Python 3.13; CUDA matrix multiplication succeeded and the real model generated `outputs/bad_day_voicetut.wav` (24 kHz, 13.11 s) plus timestamps.
- A verified MP3 render is also committed in `outputs/bad_day_voicetut.mp3` at 128 kbps, with `outputs/bad_day_voicetut.timestamps.json` updated to reference it.
- `setup_gpu.ps1` was verified on Quadro P2000: it detected the GPU, CUDA 12.6, capability sm_61, and passed a 512x512 CUDA matrix test.
- The default cu128 wheel did not support the P2000's Pascal `sm_61`; use a cu126 wheel for this GPU. The loaded weights reported 19 speakers, not the 15 names previously copied from package documentation; the adapter now uses the runtime model's valid speaker IDs and aliases `egyptian_male_1` -> Ahmed, `egyptian_female_1` -> Hanan.
- `requirements-engines.txt` now pins the compatible PyTorch/torchaudio CUDA 12.6 pair. VoiceTut keeps automatic device selection and uses float16 on CUDA, float32 on CPU. Run `setup_gpu.ps1` from the project root to verify that the detected GPU and installed packages support CUDA before synthesis.
- Still not run: `pip install -r requirements-engines.txt`, Cairo, NAMAA, Nile.
- ALWAYS run `python -m pytest -q` first in a new session. If pytest/pydantic/typer/gradio are missing and there is no network, say so; never claim a green run you did not see.
- The explanation doc is `project_exolanition.md` (renamed from the Arabic filename for Windows zip compatibility). Keep that name. `ffmpeg.exe` (Windows, 101 MB) is deliberately NOT inside the delivered zip; the user keeps their own copy in the project root. `core/audio.py: configure_ffmpeg()` uses system ffmpeg first and `ffmpeg.exe` only on Windows.

## USER DECISIONS (final, do not change without asking)
- **Words per sentence/segment: 1 to 15.** (Overrides spec 3.7 rule 4 "6 to 15".) Implemented in `data/blocked_phrases.json` -> `length`: max 15 per sentence, min 1 per segment for every part.
- **Stay strictly inside the spec's instructions** (no invented structure or CLI shapes).

## Decisions made
- Phase 3 library: `data/phrases.json` = `{category: {part: [templates]}}`, 268 phrases (>=20 per each of 12 buckets, includes the spec's own starter phrases), male form first in `{m|f}`. Robot speaks as male. Phrases are phase-neutral.
- Phase 3 mapping (`data/selection_rules.json`, matches spec 3.3 + 3.8): no mood = phase default (morning_checkin positivity; before_session encouragement; during_session comfort then encouragement; after_session encouragement; bad_day comfort; milestone encouragement then positivity; night comfort then positivity). `good` = per-phase "good" plan (encouragement or positivity, never comfort; bad_day->positivity). `tired` = comfort opening+core+closing. `anxious`/`sad` = comfort full then positivity opening+core+closing. `pain` = escalation. Every message has the 4 parts of spec 3.2 except the short form. INTERPRETATION to mention to the user: "light positivity" = the short (3-part) form.
- Selector (`core/selector.py`): `select(patient, phase, mood=None, event_text=None, *, library, rules, config, rng, memory_path, memory_size, alerts_log, callback, webhook_url) -> Selection(script, escalation, phrases)`; `select_script(...)` returns the dict only. `check_and_escalate` runs FIRST (a test proves the library is not touched on pain). Output keeps `{name}`/`{m|f}` placeholders; personalize later. Presets (speed/emotion/pause_after_ms) come from config.yaml `category_presets`; `exaggeration` is NOT in the Segment schema so it is not emitted (engines can read it from config). Last segment gets `pause_after_ms=0`.
- Memory: `.cache/recent_phrases.json` = `{"recent": [template strings]}`, trimmed to `recent_memory_size` (5). A missing/corrupt file is treated as empty. If a bucket is smaller than the window, the oldest-used phrase is reused (cannot happen with 20+).
- `speak` options: `--phase` (REQUIRED option, as in spec section 6; not positional) `--mood --patient --event-text --seed --memory-file --no-memory --alerts-log --personalized`. stdout is JSON only. Unknown phase/mood -> exit 1. Pain/emergency -> escalation script, exit 0. `--personalized` also runs `validate_script` (exit 1 on failure).
- Heavy engine deps live in `requirements-engines.txt`; core `requirements.txt` stays light (still not verified with a full `pip install -r requirements.txt`; gradio is heavy; do this re-check in Phase 0 style when a network is available).
- Schema: enums Category/Part/Phase/Mood/Gender; Message must have parts in order opening<acknowledgment<core<closing, no duplicates, `core` mandatory.
- Placeholders: `{name}` and `{male|female}` (male form first). Unresolved `{}` raises ValueError. Implementation is in `core/placeholders.py` (stdlib only); `personalize.py` wraps it (behavior unchanged).
- `output_format` is mp3 or wav. Segment speed range 0.5-1.5, pause_after_ms 0-5000.
- CLI is Typer; `generate`, `speak`, `voices` are stubs exiting with code 2 and a "Not implemented (phase N)" message.
- Safety (Phase 2): rules live in `data/blocked_phrases.json` (not in code). Text is normalized before matching (no diacritics, alef/yaa/taa-marbuta folded, Arabic digits to ASCII, punctuation to spaces); phrases match whole tokens, prefixes و ف ب ل ك tolerated. Regex entries in the JSON MUST be written in normalized form (a test enforces it).
- Safety: any mention of medication/dosage words is blocked (spec: "no talk about medicines or doses"); the word "علاج" itself is allowed. `toxic_positivity` applies to category `comfort` only. `formal_arabic` is a warning, not an error.
- Length rule (CONFIRMED by user): 1 to 15 words; max 15 per sentence (split on . ! ? ؟ newline, NOT on "…"), min 1 per segment for every part.
- Escalation: false positives are intentional (e.g. "مش عايز أموت" still triggers). Log, callback and webhook are independent; failures go to `EscalationResult.errors` and never block the calming line. Webhook accepts http/https only.
- Fixed Arabic lines are constants in `core/safety.py`: `ESCALATION_LINE`, `MEDICAL_QUESTION_REPLY`. Both pass the validator (tested).

## Public API of core/safety.py (use it, do not re-implement)
- `get_validator()` -> shared `ContentValidator`.
- `validator.validate_template(text, category, part)` for raw phrases with placeholders (checks both genders). Use it for phrases.json and the library tab.
- `validator.validate_text(text, category, part)` / `validate_script(script)` for personalized text (pipeline step 3).
- `validator.is_medical_question(text)` -> reply with `MEDICAL_QUESTION_REPLY`.
- `check_and_escalate(patient, phase, mood=None, event_text=None, alerts_log=..., callback=..., webhook_url=...)` -> `EscalationResult` or None. `.script` is a schema-shaped dict (one comfort/core segment) that replaces the normal script. The selector must call this FIRST and return `.script` when it is not None.
- `SafetyResult.ok`, `.errors`, `.warnings`, `.reasons("ar"|"en")`.

## Files existing now
main.py (validate, speak working; generate and voices are stubs), config.yaml, requirements.txt, requirements-engines.txt, core/{schema,placeholders,personalize,safety,selector}.py, data/{blocked_phrases,phrases,selection_rules}.json, examples/*.json, tests/{test_schema,test_personalize,test_safety,test_selector}.py, شرح_المشروع.md, NEXT_MODEL_PROMPT.md. Empty: core/__init__.py, engines/__init__.py, tests/__init__.py, logs/, outputs/. Run tests from the project root.

## Phase 5 decisions (done)
- `core/pipeline.py: run_pipeline(script, engine, out_path, *, config, cache, pronunciation, validator, voice) -> PipelineResult` (audio_path, timestamps_path, timestamps, duration_ms, cache_hits/misses, warnings). Raises pydantic.ValidationError, `SafetyRejection` (before any synthesis), `EngineError`, `ExportError`. Reads new `audio:` and `preprocess:` blocks of config.yaml (defaults in `DEFAULT_AUDIO`).
- Output extension (.mp3/.wav) of `--out` wins; if none, `script.output_format` is appended. Timestamps file = `<stem>.timestamps.json` next to the audio.
- Engines that do not report `supports("speed")` get WSOLA time-stretch in `core/audio.py`; engines that do receive `speed` as a param. Same for `emotion`. Cache key uses `engine.model_id` if defined, else `engine.name` (add `model_id` to real adapters).
- Assembly uses pydub; every segment is loudness-normalized to -23 LUFS, fade-in 150ms on the first segment of each message (10ms otherwise), fade-out 30ms.
- `data/pronunciation.json` is `{}` on purpose (no invented pronunciations); an Egyptian speaker should fill it.
- Numbers: spoken up to 999,999 (Egyptian words); above that or with leading zeros: digit by digit. Decimals are not handled.

## Known deviations from the spec's file list (fix in Phase 8 or earlier if cheap)
- Spec lists `engines/voicetut_engine.py`, `namaa_engine.py`, `xtts_engine.py`; the project currently uses `engines/optional.py` + `registry.py` (install-hint stubs only, no real synthesis). Either create the three files as thin adapters (read each README first) or tell the user.
- `NEXT_MODEL_PROMPT.md` still says 214 passed (stale); real numbers are in this file.

## VoiceTut adapter decisions (verified against voicetut-tts 0.1.1 source and the actual downloaded model)
- API: `VoiceTutTTS.from_pretrained(repo, device=, dtype=)`; `synthesize(text, speaker=|ref_audio=+ref_text=, language="arz", speed=...) -> 1-D float32`; `.sampling_rate`. The running model reported 19 built-in speakers (see `BUILTIN_SPEAKERS` in engines/voicetut_engine.py).
- Actual speaker IDs are Ahmed, Ali, Hassan, Karim, Mahmoud, Mohammed, Mostafa, Ramy, Shaker, Tareq, Yehia, Youssef, Hadeer, Hanan, Mariam, Rana, Sarah, Yasmin, and Yara. The earlier 15-name list was not valid for these downloaded weights; `Mohammed` is valid and `Hossam` is not.
- Project aliases: `egyptian_male_1` -> Ahmed, `egyptian_female_1` -> Hanan. Default voice = first in list = `egyptian_male_1` (the robot's phrases use male forms).
- Speed is native (`supports("speed")` True); emotion unsupported (adapter raises if given). CPU -> float32, CUDA -> float16, auto-detected, overridable via config `voicetut.device` / `voicetut.dtype`.
- Cloning: any `voices/<name>.wav` (+ optional `<name>.txt` transcript) is listed as a voice.

## What remains
1. Clinician review of `data/blocked_phrases.json`; native-speaker review of the 268 phrases; fill `data/pronunciation.json` (currently `{}` on purpose).
2. Optional: install and verify Cairo, NAMAA, and Nile-XTTS adapters.

## Optional next work (not required by the spec)
- Real adapters for NAMAA and Nile-XTTS (still install-hint stubs in `engines/optional.py`; spec lists separate files `namaa_engine.py`, `xtts_engine.py`). Read each model card first.
- Speaker gender for VoiceTut voices is inferred from names; read it from `model.list_speakers()` once the model is loaded.
- Decimals in numbers are not spoken; numbers above 999,999 are read digit by digit.

## Open decisions for the user
- Whether the blocked-phrase list should be reviewed by a clinician before real use. - Confirm the interpretation of "light positivity" (3-part form). - Native-speaker review of the 268 phrases (tone, dialect, gender forms).

## Phase 4 completion details
- engines/base.py, mock_engine.py, cairo_engine.py, optional.py, and registry.py implement the engine interface and registry. Cairo-TTS and optional packages are imported lazily.
- voices --engine mock lists mock_female and mock_male. Cairo lists its 20 documented preset IDs after checking that the package is installed; no model weights are downloaded by this command.
- Mock audio is deterministic mono float32 at 22,050 Hz. Cairo output is read as mono float32 and retains the model's returned sample rate.
- Cairo does not expose speed or emotion controls in the documented API. Speed must be applied by the Phase 5 audio post-processor.
- Optional VoiceTut, NAMAA and Nile-XTTS currently stop at package detection and install hints; their synthesis adapters are still future work.
- Test command: python -m pytest -q -> 222 passed, 14 dependency deprecation warnings.
