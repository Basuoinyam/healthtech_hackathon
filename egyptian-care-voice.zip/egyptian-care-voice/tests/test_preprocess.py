import pytest

from core.preprocess import (apply_pronunciation, clean_text, number_to_words, numbers_to_words,
                             prepare_text, split_long)


@pytest.mark.parametrize("n,expected", [
    (0, "صفر"), (3, "تلاتة"), (11, "حداشر"), (21, "واحد وعشرين"), (100, "مية"),
    (125, "مية وخمسة وعشرين"), (1000, "ألف"), (2000, "ألفين"), (3000, "تلات تلاف"),
    (12000, "اتناشر ألف"), (1500, "ألف وخمسمية"),
])
def test_number_to_words(n, expected):
    assert number_to_words(n) == expected


def test_number_out_of_range():
    with pytest.raises(ValueError):
        number_to_words(1_000_000)


def test_numbers_in_text_arabic_and_ascii_digits():
    assert numbers_to_words("جلسة ٣ و 21") == "جلسة تلاتة و واحد وعشرين"


def test_leading_zero_and_huge_numbers_read_digit_by_digit():
    assert numbers_to_words("007") == "صفر صفر سبعة"
    assert numbers_to_words("1234567") == "واحد اتنين تلاتة أربعة خمسة ستة سبعة"


def test_clean_text():
    assert clean_text("  أهلاً   *يا*  صديقي !!! ") == "أهلاً يا صديقي!"
    assert clean_text("كلام\u200b جميل ـ") == "كلام جميل"


def test_pronunciation_whole_words_only():
    d = {"دكتور": "دُكتور"}
    assert apply_pronunciation("الدكتور جاي، دكتور كويس", d) == "الدكتور جاي، دُكتور كويس"


def test_split_long_respects_limit_and_keeps_all_words():
    text = " ".join(f"كلمة{i}" for i in range(40)) + "."
    chunks = split_long(text, 15)
    assert all(len(c.split()) <= 15 for c in chunks)
    assert " ".join(chunks).replace(".", "").split() == text.replace(".", "").split()


def test_split_prefers_sentence_and_comma_boundaries():
    assert split_long("أهلاً بيك. عامل إيه؟ أنا هنا", 15) == ["أهلاً بيك.", "عامل إيه؟", "أنا هنا"]
    long = "واحد اتنين تلاتة أربعة خمسة، ستة سبعة تمانية تسعة عشرة"
    assert split_long(long, 6) == ["واحد اتنين تلاتة أربعة خمسة،", "ستة سبعة تمانية تسعة عشرة"]


def test_prepare_text_pipeline():
    assert prepare_text("عندك ٢ جلسات", {}, 15) == ["عندك اتنين جلسات"]
    assert prepare_text("   ", {}, 15) == []
