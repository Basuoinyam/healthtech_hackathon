import json
from pathlib import Path

import pytest
from pydantic import ValidationError
from typer.testing import CliRunner

from core.cache import AudioCache
from core.pipeline import SafetyRejection, run_pipeline
from core.safety import build_escalation_script
from engines.mock_engine import MockEngine
from main import app

EX = Path(__file__).resolve().parent.parent / "examples"
CFG = {"category_presets": {"comfort": {"speed": 0.9, "pause_after_ms": 500}}, "audio": {},
       "preprocess": {"max_chunk_words": 15}}


def load(name):
    return json.loads((EX / f"{name}.json").read_text(encoding="utf-8"))


def run(script, tmp_path, name="out.mp3", engine=None, cache=None):
    cache = cache or AudioCache(tmp_path / "cache")
    return run_pipeline(script, engine or MockEngine(), tmp_path / name, config=CFG, cache=cache,
                        pronunciation={})


@pytest.mark.parametrize("name", ["before_session_anxious", "bad_day", "milestone"])
def test_examples_generate_audio_and_timestamps(name, tmp_path):
    res = run(load(name), tmp_path, f"{name}.mp3")
    assert res.audio_path.exists() and res.audio_path.stat().st_size > 1000
    data = json.loads(res.timestamps_path.read_text(encoding="utf-8"))
    segs = data["segments"]
    assert segs and data["duration_ms"] == res.duration_ms
    assert all(s["start_ms"] < s["end_ms"] for s in segs)
    assert all(a["end_ms"] <= b["start_ms"] for a, b in zip(segs, segs[1:]))
    assert {"text", "category", "part"} <= set(segs[0])


def test_timestamps_contain_personalized_text(tmp_path):
    res = run(load("bad_day"), tmp_path)
    assert all("{" not in t["text"] and "|" not in t["text"] for t in res.timestamps)
    assert res.timestamps[0]["text"] == "أهلاً يا أبو محمد"


def test_second_run_uses_cache(tmp_path):
    cache = AudioCache(tmp_path / "cache")
    first = run(load("bad_day"), tmp_path, cache=cache)
    second = run(load("bad_day"), tmp_path, cache=cache)
    assert first.cache_hits == 0 and first.cache_misses > 0
    assert second.cache_misses == 0 and second.cache_hits == first.cache_misses


def test_wav_output_by_extension(tmp_path):
    res = run(load("bad_day"), tmp_path, "x.wav")
    assert res.audio_path.suffix == ".wav" and res.audio_path.exists()


def test_extension_added_from_script_format(tmp_path):
    res = run(load("bad_day"), tmp_path, "noext")
    assert res.audio_path.name == "noext.wav"  # bad_day.json asks for wav


def test_invalid_script_raises_validation_error(tmp_path):
    with pytest.raises(ValidationError):
        run({"phase": "x"}, tmp_path)


def test_unsafe_script_is_rejected_before_synthesis(tmp_path):
    s = load("bad_day")
    s["messages"][0]["segments"][2]["text"] = "هتخف أكيد من غير أي مشكلة"
    class Boom(MockEngine):
        def synthesize(self, *a, **k):
            raise AssertionError("engine must not be called")
    with pytest.raises(SafetyRejection) as e:
        run(s, tmp_path, engine=Boom())
    assert "Guaranteed" in str(e.value)


def test_escalation_script_is_synthesizable(tmp_path):
    script = build_escalation_script({"name": "سارة", "gender": "female"}, "bad_day")
    res = run(script, tmp_path)
    assert res.audio_path.exists() and len(res.timestamps) == 1


def test_unknown_voice_falls_back_with_warning(tmp_path):
    res = run(load("before_session_anxious"), tmp_path)  # preferred_voice is not a mock voice
    assert any("egyptian_female_1" in w for w in res.warnings)


def test_engine_without_speed_support_uses_time_stretch(tmp_path):
    class NoSpeed(MockEngine):
        def supports(self, feature):
            return False
    plain = run(load("bad_day"), tmp_path, "a.mp3", engine=NoSpeed(), cache=AudioCache(tmp_path / "c1"))
    assert plain.duration_ms > 0


def test_cli_generate_mock_and_missing_engine(tmp_path):
    out = tmp_path / "cli.mp3"
    r = CliRunner().invoke(app, ["generate", str(EX / "milestone.json"), "--engine", "mock",
                                 "--out", str(out), "--no-cache"])
    assert r.exit_code == 0, r.output
    assert out.exists() and (tmp_path / "cli.timestamps.json").exists()
    r = CliRunner().invoke(app, ["generate", str(EX / "milestone.json"), "--engine", "nope",
                                 "--out", str(tmp_path / "z.mp3")])
    assert r.exit_code == 1 and "Unknown engine" in r.output
