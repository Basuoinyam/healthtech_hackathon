"""Tests for engine interface and the voices command."""
import importlib.util

import pytest
from typer.testing import CliRunner

from engines import get_engine
from engines.base import EngineUnavailableError
from engines.mock_engine import MockEngine
from main import app


def test_mock_engine_is_deterministic_and_returns_audio():
    engine = MockEngine()
    first, sample_rate = engine.synthesize("أهلاً يا صديقي", "mock_female")
    second, second_rate = engine.synthesize("أهلاً يا صديقي", "mock_female")
    assert sample_rate == second_rate == 22050
    assert first.dtype.name == "float32"
    assert first.ndim == 1 and first.size > 0
    assert (first == second).all()


def test_mock_engine_voice_list():
    assert MockEngine().list_voices() == ["mock_female", "mock_male"]


def test_voices_cli_lists_mock_voices():
    result = CliRunner().invoke(app, ["voices", "--engine", "mock"])
    assert result.exit_code == 0, result.output
    assert "mock_female" in result.stdout
    assert "mock_male" in result.stdout


def test_voices_cli_reports_unknown_engine_without_traceback():
    result = CliRunner().invoke(app, ["voices", "--engine", "unknown"])
    assert result.exit_code == 1
    assert "Available engines" in result.stderr
    assert "Traceback" not in result.stderr


@pytest.mark.parametrize(
    "engine,module_name,install_hint",
    [
        ("cairo", "cairo_tts", "pip install cairo-tts"),
        ("namaa", "chatterbox", "pip install chatterbox-tts"),
        ("nile-xtts", "TTS", "pip install coqui-tts"),
    ],
)
def test_missing_engine_package_has_install_hint(engine, module_name, install_hint):
    if importlib.util.find_spec(module_name) is not None:
        pytest.skip(f"{module_name} is installed")
    with pytest.raises(EngineUnavailableError, match=install_hint.replace(".", r"\.")):
        get_engine(engine).list_voices()


def test_voicetut_voice_list_is_lazy_and_has_fallbacks():
    from engines.voicetut_engine import VoiceTutEngine
    engine = VoiceTutEngine(voices_dir="nonexistent-voices-folder")
    voices = engine.list_voices()
    assert voices[:2] == ["egyptian_male_1", "egyptian_female_1"] and "Hanan" in voices
    assert engine._model is None
