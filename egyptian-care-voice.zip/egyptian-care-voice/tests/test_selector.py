"""Tests for the phrase library, the selector and the speak command (phase 3)."""
import itertools
import json
import random

import pytest
from typer.testing import CliRunner

from core.personalize import personalize_script
from core.safety import ESCALATION_LINE, get_validator
from core.schema import Category, Mood, Part, Phase, Script
from core.selector import load_library, load_recent, select
from main import app

FEMALE = {"name": "سارة", "gender": "female"}
MALE = {"name": "أحمد", "gender": "male"}
NON_PAIN = [m for m in Mood if m is not Mood.pain]
LIB = load_library()


# ---- phrase library ---------------------------------------------------------
def test_library_has_every_bucket_with_20_plus():
    for cat in Category:
        for part in Part:
            assert len(LIB[cat.value][part.value]) >= 20, (cat, part)


def test_library_has_no_duplicates_or_unknown_keys():
    assert set(LIB) == {c.value for c in Category}
    for cat, parts in LIB.items():
        assert set(parts) == {p.value for p in Part}
        for part, phrases in parts.items():
            assert len(phrases) == len(set(phrases)), (cat, part)


def test_every_phrase_passes_the_validator():
    v = get_validator()
    failures = []
    for cat, parts in LIB.items():
        for part, phrases in parts.items():
            for text in phrases:
                r = v.validate_template(text, cat, part)
                if r.violations:
                    failures.append((cat, part, text, r.reasons()))
    assert not failures, failures


def test_every_phrase_resolves_for_both_genders():
    from core.placeholders import resolve_placeholders
    for parts in LIB.values():
        for phrases in parts.values():
            for text in phrases:
                for g in ("male", "female"):
                    out = resolve_placeholders(text, "سارة", g)
                    assert "{" not in out and "|" not in out


# ---- every phase x mood -----------------------------------------------------
@pytest.mark.parametrize("phase,mood", list(itertools.product(Phase, NON_PAIN)))
def test_valid_script_for_every_phase_and_mood(phase, mood):
    sel = select(FEMALE, phase, mood, rng=random.Random(1))
    assert not sel.escalated
    script = Script.model_validate(sel.script)
    assert get_validator().validate_script(personalize_script(script)).ok


@pytest.mark.parametrize("phase", list(Phase))
def test_valid_script_without_mood(phase):
    Script.model_validate(select(MALE, phase, None, rng=random.Random(2)).script)


@pytest.mark.parametrize("phase", list(Phase))
def test_pain_escalates_for_every_phase(phase, tmp_path):
    log = tmp_path / "alerts.log"
    sel = select(FEMALE, phase, "pain", alerts_log=log)
    assert sel.escalated
    assert sel.script["messages"][0]["segments"][0]["text"] == ESCALATION_LINE
    Script.model_validate(sel.script)
    assert json.loads(log.read_text(encoding="utf-8").splitlines()[0])["reason"] == "mood_pain"


def test_emergency_text_escalates_even_if_mood_is_good(tmp_path):
    sel = select(FEMALE, "night", "good", "مش قادرة اتنفس", alerts_log=tmp_path / "a.log")
    assert sel.escalated and sel.escalation.reason == "emergency_text"


def test_escalation_runs_before_library_is_touched(tmp_path):
    # An empty library would crash normal selection; escalation must not need it.
    sel = select(FEMALE, "night", "pain", library={}, rules={}, alerts_log=tmp_path / "a.log")
    assert sel.escalated


def test_unknown_phase_or_mood_raises():
    with pytest.raises(ValueError):
        select(FEMALE, "lunch", "good")
    with pytest.raises(ValueError):
        select(FEMALE, "night", "angry")


# ---- structure rules --------------------------------------------------------
def parts_of(script):
    return [[s["part"] for s in m["segments"]] for m in script["messages"]]


def cats_of(script):
    return [m["category"] for m in script["messages"]]


FULL = ["opening", "acknowledgment", "core", "closing"]
SHORT = ["opening", "core", "closing"]

# Spec 3.3 table: primary categories per phase when no mood is given.
PHASE_DEFAULTS = {
    "morning_checkin": ["positivity"],
    "before_session": ["encouragement"],
    "during_session": ["comfort", "encouragement"],
    "after_session": ["encouragement"],
    "bad_day": ["comfort"],
    "milestone": ["encouragement", "positivity"],
    "night": ["comfort", "positivity"],
}
# Spec 3.8: "good" = encouragement or positivity depending on the phase (never comfort).
GOOD_PHASES = {
    "morning_checkin": ["positivity"], "before_session": ["encouragement"],
    "during_session": ["encouragement"], "after_session": ["encouragement"],
    "bad_day": ["positivity"], "milestone": ["encouragement", "positivity"],
    "night": ["positivity"],
}


@pytest.mark.parametrize("phase", list(Phase))
def test_no_mood_uses_the_primary_categories_of_spec_3_3(phase):
    script = select(FEMALE, phase, None, rng=random.Random(8)).script
    assert cats_of(script) == PHASE_DEFAULTS[phase.value]
    assert parts_of(script) == [FULL] * len(script["messages"])


@pytest.mark.parametrize("phase", list(Phase))
def test_good_mood_is_encouragement_or_positivity(phase):
    script = select(FEMALE, phase, "good", rng=random.Random(9)).script
    assert cats_of(script) == GOOD_PHASES[phase.value]
    assert "comfort" not in cats_of(script)
    assert parts_of(script) == [FULL] * len(script["messages"])


@pytest.mark.parametrize("phase", list(Phase))
def test_tired_is_comfort_opening_core_closing_only(phase):
    script = select(FEMALE, phase, "tired", rng=random.Random(3)).script
    assert cats_of(script) == ["comfort"]
    assert parts_of(script) == [SHORT]


@pytest.mark.parametrize("mood", ["anxious", "sad"])
@pytest.mark.parametrize("phase", list(Phase))
def test_anxious_and_sad_are_comfort_then_light_positivity(phase, mood):
    script = select(FEMALE, phase, mood, rng=random.Random(4)).script
    assert cats_of(script) == ["comfort", "positivity"]
    assert parts_of(script) == [FULL, SHORT]


def test_phrases_come_from_the_matching_bucket():
    script = select(FEMALE, "milestone", "good", rng=random.Random(6)).script
    for msg in script["messages"]:
        for seg in msg["segments"]:
            assert seg["text"] in LIB[msg["category"]][seg["part"]]


def test_presets_applied_and_no_dead_air_at_end():
    script = select(FEMALE, "bad_day", None, rng=random.Random(7)).script
    segs = script["messages"][0]["segments"]
    assert all(s["speed"] == 0.88 and s["emotion"] == "calm" for s in segs)
    assert segs[0]["pause_after_ms"] == 800 and segs[-1]["pause_after_ms"] == 0


# ---- recent-phrase memory ---------------------------------------------------
def test_no_phrase_repeats_within_last_5_across_many_runs(tmp_path):
    mem = tmp_path / "recent.json"
    rng = random.Random(42)
    sequence = []
    for i in range(300):
        phase = list(Phase)[i % len(Phase)]
        mood = [None, "good", "tired", "anxious", "sad"][i % 5]
        sel = select(FEMALE, phase, mood, rng=rng, memory_path=mem, memory_size=5)
        sequence += sel.phrases
    for i, text in enumerate(sequence):
        assert text not in sequence[max(0, i - 5):i], (i, text)


def test_memory_file_keeps_only_last_5(tmp_path):
    mem = tmp_path / "sub" / "recent.json"
    for _ in range(4):
        select(FEMALE, "after_session", "sad", rng=random.Random(), memory_path=mem)
    assert len(load_recent(mem)) == 5


def test_corrupt_memory_file_is_ignored(tmp_path):
    mem = tmp_path / "recent.json"
    mem.write_text("{not json", encoding="utf-8")
    Script.model_validate(select(FEMALE, "night", "good", memory_path=mem).script)
    assert len(load_recent(mem)) > 0


def test_small_bucket_falls_back_to_least_recently_used():
    lib = {c: {p: ["أ ب", "ج د"] for p in ("opening", "acknowledgment", "core", "closing")}
           for c in ("encouragement", "positivity", "comfort")}
    sel = select(FEMALE, "before_session", "good", library=lib, memory_size=5, rng=random.Random(1))
    assert len(sel.phrases) == 4
    # with 2 phrases to choose from, the same phrase is never used twice in a row
    assert all(a != b for a, b in zip(sel.phrases, sel.phrases[1:]))


# ---- CLI --------------------------------------------------------------------
runner = CliRunner()


def run_speak(tmp_path, *args):
    return runner.invoke(app, ["speak", *args, "--memory-file", str(tmp_path / "m.json"),
                               "--alerts-log", str(tmp_path / "a.log")])


@pytest.mark.parametrize("phase,mood", list(itertools.product(Phase, NON_PAIN)))
def test_cli_speak_outputs_valid_json(tmp_path, phase, mood):
    res = run_speak(tmp_path, "--phase", phase.value, "--mood", mood.value, "--seed", "1")
    assert res.exit_code == 0, res.output
    Script.model_validate(json.loads(res.stdout))


def test_cli_speak_pain_prints_escalation_and_exits_zero(tmp_path):
    res = run_speak(tmp_path, "--phase", "night", "--mood", "pain")
    assert res.exit_code == 0
    assert ESCALATION_LINE in json.loads(res.stdout)["messages"][0]["segments"][0]["text"]
    assert (tmp_path / "a.log").read_text(encoding="utf-8").strip()


def test_cli_speak_event_text_escalates(tmp_path):
    res = run_speak(tmp_path, "--phase", "morning_checkin", "--event-text", "الحقوني")
    assert res.exit_code == 0 and ESCALATION_LINE in res.stdout


def test_cli_speak_personalized_has_no_placeholders(tmp_path):
    res = run_speak(tmp_path, "--phase", "milestone", "--mood", "good", "--personalized", "--seed", "3")
    assert res.exit_code == 0
    texts = [seg["text"] for m in json.loads(res.stdout)["messages"] for seg in m["segments"]]
    assert all("{" not in t and "}" not in t for t in texts)
    assert any("أم أحمد" in t for t in texts)


def test_cli_speak_rejects_unknown_phase(tmp_path):
    assert run_speak(tmp_path, "--phase", "lunch").exit_code == 1
    assert run_speak(tmp_path, "--phase", "night", "--mood", "angry").exit_code == 1


def test_cli_speak_requires_phase_option(tmp_path):
    assert run_speak(tmp_path).exit_code != 0


def test_cli_speak_never_repeats_last_5(tmp_path):
    seq = []
    for _ in range(40):
        res = run_speak(tmp_path, "--phase", "after_session", "--mood", "anxious")
        script = json.loads(res.stdout)
        seq += [s["text"] for m in script["messages"] for s in m["segments"]]
    for i, t in enumerate(seq):
        assert t not in seq[max(0, i - 5):i]
