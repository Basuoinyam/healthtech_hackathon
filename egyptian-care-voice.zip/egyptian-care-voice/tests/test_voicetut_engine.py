import json
import sys
import types

import numpy as np
import pytest
from pydub import AudioSegment

from core.cache import AudioCache
from core.pipeline import run_pipeline
from engines.voicetut_engine import VoiceTutEngine


def test_init_and_voice_listing_do_not_import_model(monkeypatch, tmp_path):
    import importlib
    imported = []
    original_import = importlib.import_module
    def track_import(name, *args, **kwargs):
        if name == "voicetut_tts":
            imported.append(name)
        return original_import(name, *args, **kwargs)
    monkeypatch.setattr(importlib, "import_module", track_import)
    engine = VoiceTutEngine(voices_dir=tmp_path / "missing")
    voices = engine.list_voices()
    assert voices[:2] == ["egyptian_male_1", "egyptian_female_1"] and "Ahmed" in voices and len(voices) == 21
    assert engine._model is None
    assert imported == []


def _mock_package(monkeypatch, model):
    class FakeVoiceTut:
        @classmethod
        def from_pretrained(cls, model_id, **kwargs):
            assert model_id == "mohammedaly22/VoiceTut-TTS"
            return model
    monkeypatch.setitem(sys.modules, "voicetut_tts", types.SimpleNamespace(VoiceTutTTS=FakeVoiceTut))


def test_synthesize_returns_normalized_mono_float32(monkeypatch, tmp_path):
    class Model:
        sampling_rate = 24000
        def synthesize(self, text, **kwargs):
            assert kwargs["speaker"] == "Hanan" and kwargs["speed"] == 1.0 and kwargs["language"] == "arz"
            return np.array([[0.0, 2.0], [-2.0, 0.5]], dtype=np.float32)

    model = Model()
    _mock_package(monkeypatch, model)
    engine = VoiceTutEngine(voices_dir=tmp_path / "voices")
    waveform, sample_rate = engine.synthesize("ازيك", "egyptian_female_1")
    assert waveform.ndim == 1 and waveform.dtype == np.float32
    assert sample_rate == 24000 and np.max(np.abs(waveform)) == 1.0
    assert engine._model is model


@pytest.mark.parametrize("fmt", ["wav", "mp3"])
def test_pipeline_exports_audio_and_timestamps_with_mock_voicetut(monkeypatch, tmp_path, fmt):
    class Model:
        sampling_rate = 24000
        def synthesize(self, text, **kwargs):
            # Deterministic audible tone; the integration tests only exercise the adapter contract.
            return (np.sin(np.arange(6000) * 0.04) * 0.2).astype(np.float32)

    _mock_package(monkeypatch, Model())
    engine = VoiceTutEngine(voices_dir=tmp_path / "voices")
    script = {
        "phase": "bad_day",
        "patient": {"name": "سارة", "gender": "female"},
        "output_format": fmt,
        "messages": [{"category": "comfort", "segments": [{"text": "أنا هنا معاكي", "part": "core"}]}],
    }
    result = run_pipeline(
        script, engine, tmp_path / f"speech.{fmt}",
        config={"audio": {}, "category_presets": {}, "preprocess": {"max_chunk_words": 15}},
        cache=AudioCache(tmp_path / "cache"), pronunciation={},
    )
    assert result.audio_path.exists()
    assert result.timestamps_path.exists()
    assert json.loads(result.timestamps_path.read_text(encoding="utf-8"))["engine"] == "voicetut"
    # Confirm the output is non-empty.
    assert result.audio_path.stat().st_size > 100


def test_builtin_names_are_real_package_speakers():
    from engines.voicetut_engine import BUILTIN_SPEAKERS, DEFAULT_ALIASES
    assert len(BUILTIN_SPEAKERS) == 19
    assert "Mohammed" in BUILTIN_SPEAKERS and "Mohamed" not in BUILTIN_SPEAKERS
    assert all(target in BUILTIN_SPEAKERS for target in DEFAULT_ALIASES.values())


def test_speed_and_cloning_supported_emotion_not(tmp_path):
    e = VoiceTutEngine(voices_dir=tmp_path)
    assert e.supports("speed") and e.supports("cloning") and not e.supports("emotion")


def test_cloned_voice_uses_ref_audio_and_transcript(monkeypatch, tmp_path):
    (tmp_path / "mama.wav").write_bytes(b"RIFF")
    (tmp_path / "mama.txt").write_text("ده صوتي", encoding="utf-8")
    seen = {}

    class Model:
        sampling_rate = 24000
        def synthesize(self, text, **kwargs):
            seen.update(kwargs)
            return np.ones(100, np.float32) * 0.1

    _mock_package(monkeypatch, Model())
    engine = VoiceTutEngine(voices_dir=tmp_path, device="cpu", dtype="float32")
    assert "mama" in engine.list_voices()
    engine.synthesize("أهلا", "mama", speed=0.9)
    assert seen["ref_audio"].endswith("mama.wav") and seen["ref_text"] == "ده صوتي"
    assert "speaker" not in seen and seen["speed"] == 0.9


def test_unknown_voice_and_missing_package(monkeypatch, tmp_path):
    from engines.base import EngineUnavailableError
    engine = VoiceTutEngine(voices_dir=tmp_path)
    with pytest.raises(ValueError):
        engine.synthesize("x", "nobody")
    monkeypatch.setitem(sys.modules, "voicetut_tts", None)  # simulates ImportError
    with pytest.raises(EngineUnavailableError) as e:
        engine.synthesize("أهلا", "Ahmed")
    assert "requirements-engines.txt" in str(e.value)
