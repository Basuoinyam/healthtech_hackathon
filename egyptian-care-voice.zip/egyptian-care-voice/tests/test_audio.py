import numpy as np
import pytest

from core import audio as au

SR = 22050


def tone(seconds=1.0, amp=0.1, freq=220.0):
    t = np.arange(int(SR * seconds), dtype=np.float32) / SR
    return (amp * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_fade_in_starts_silent_and_ends_untouched():
    out = au.fade_in(np.ones(SR, np.float32), SR, 100)
    assert out[0] == 0.0 and out[-1] == 1.0 and 0 < out[len(out) // 20] < 1


def test_fade_out_ends_silent():
    out = au.fade_out(np.ones(SR, np.float32), SR, 100)
    assert out[0] == 1.0 and abs(out[-1]) < 1e-3


def test_loudness_equalizes_quiet_and_loud_clips():
    import pyloudnorm as pyln
    meter = pyln.Meter(SR)
    levels = [meter.integrated_loudness(au.normalize_loudness(tone(1.0, a), SR, -23.0).astype(np.float64))
              for a in (0.01, 0.3)]
    assert all(abs(l + 23.0) < 0.5 for l in levels)


def test_loudness_handles_short_and_silent_clips():
    assert au.normalize_loudness(tone(0.1), SR).size == int(SR * 0.1)
    silent = np.zeros(SR, np.float32)
    assert (au.normalize_loudness(silent, SR) == 0).all()


def test_peak_is_capped():
    out = au.normalize_loudness(tone(1.0, 0.9), SR, -10.0)
    assert np.max(np.abs(out)) <= au.TARGET_PEAK + 1e-6


@pytest.mark.parametrize("rate", [0.8, 1.25])
def test_time_stretch_changes_duration(rate):
    x = tone(2.0)
    y = au.time_stretch(x, rate)
    assert abs(len(y) / (len(x) / rate) - 1) < 0.05


def test_time_stretch_noop_near_one():
    x = tone(1.0)
    assert au.time_stretch(x, 1.0) is x


def test_export_wav_and_bad_format(tmp_path):
    seg = au.to_segment(tone(0.5), SR)
    p = au.export_audio(seg, tmp_path / "a.wav", "wav")
    assert p.exists() and p.stat().st_size > 1000
    with pytest.raises(au.ExportError):
        au.export_audio(seg, tmp_path / "a.ogg", "ogg")
