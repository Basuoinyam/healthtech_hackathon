import json
import shutil
from pathlib import Path

import pytest

import app
from core.cache import AudioCache
from core.selector import DEFAULT_PHRASES_PATH, load_config

CFG = load_config()
MOCK_CFG = {**CFG, "default_engine": "mock"}


@pytest.fixture()
def lib(tmp_path):
    p = tmp_path / "phrases.json"
    shutil.copy(DEFAULT_PHRASES_PATH, p)
    return p


def count(p, cat="encouragement", part="core"):
    return len(json.loads(Path(p).read_text(encoding="utf-8"))[cat][part])


# ---- phrase library: the Safety Validator guards every write -----------------------
def test_add_valid_phrase_is_saved(lib):
    before = count(lib)
    ok, msg = app.library_add("encouragement", "core", "{انت|انتي} بتتقدم {يوم|يوم} بعد يوم", lib)
    assert ok, msg
    assert count(lib) == before + 1


@pytest.mark.parametrize("bad", ["هتخف أكيد", "خد حبتين من الدوا", "{foo}", "   "])
def test_unsafe_or_broken_phrase_is_rejected_and_file_unchanged(lib, bad):
    raw = lib.read_bytes()
    ok, msg = app.library_add("encouragement", "core", bad, lib)
    assert not ok and msg
    assert lib.read_bytes() == raw


def test_toxic_positivity_rejected_only_in_comfort(lib):
    assert not app.library_add("comfort", "core", "ماتزعلش خالص", lib)[0]


def test_duplicate_rejected(lib):
    existing = json.loads(lib.read_text(encoding="utf-8"))["comfort"]["core"][0]
    assert not app.library_add("comfort", "core", existing, lib)[0]


def test_update_validates_and_delete_keeps_minimum(lib):
    assert app.library_update("comfort", "core", 0, "هتخف أكيد", lib)[0] is False
    assert app.library_update("comfort", "core", 0, "أنا هنا {معاك|معاكي} دايماً", lib)[0] is True
    assert count(lib, "comfort", "opening") == 20
    assert app.library_delete("comfort", "opening", 0, lib)[0] is False  # buckets must keep 20+
    assert app.library_add("comfort", "opening", "يا {حبيبي|حبيبتي}، أنا جنبك", lib)[0]
    assert app.library_delete("comfort", "opening", 20, lib)[0] is True


def test_unknown_bucket_and_index(lib):
    assert not app.library_add("nope", "core", "جملة حلوة", lib)[0]
    assert not app.library_update("comfort", "core", 999, "جملة حلوة", lib)[0]


def test_library_rows_shape(lib):
    rows = app.library_rows("comfort", "core", lib)
    assert rows[0][0] == 0 and isinstance(rows[0][1], str) and len(rows) >= 20


# ---- robot / editor tabs ------------------------------------------------------------
def test_generate_message_returns_valid_script_and_text():
    script, text, status = app.generate_message("سارة", "female", "before_session", "anxious",
                                                config=CFG, use_memory=False)
    assert json.loads(script)["phase"] == "before_session" and "{" not in text and "تم توليد" in status


def test_generate_message_pain_escalates(tmp_path):
    cfg = {**CFG, "alerts_log": str(tmp_path / "alerts.log")}
    script, text, status = app.generate_message("سارة", "female", "bad_day", "pain", config=cfg, use_memory=False)
    assert "التصعيد" in status and "هبلّغ" in text
    assert (tmp_path / "alerts.log").exists()


def test_generate_message_bad_phase_shows_arabic_error():
    script, text, status = app.generate_message("x", "male", "nope", config=CFG, use_memory=False)
    assert script == "" and status


def test_validate_script_json_variants():
    good = (Path(__file__).resolve().parent.parent / "examples" / "bad_day.json").read_text(encoding="utf-8")
    assert app.validate_script_json(good).startswith("✅")
    assert "JSON" in app.validate_script_json("{oops")
    assert "أخطاء" in app.validate_script_json("{}")
    unsafe = json.loads(good)
    unsafe["messages"][0]["segments"][2]["text"] = "هتخف أكيد من غير أي مشكلة"
    assert "الأمان" in app.validate_script_json(json.dumps(unsafe, ensure_ascii=False))


def test_render_audio_and_segment_with_mock(tmp_path):
    good = (Path(__file__).resolve().parent.parent / "examples" / "milestone.json").read_text(encoding="utf-8")
    cache = AudioCache(tmp_path / "c")
    path, files, note = app.render_audio(good, "mock", None, config=MOCK_CFG, out_dir=tmp_path, cache=cache)
    assert path and Path(path).exists() and len(files) == 2 and "تم التوليد" in note
    rows = app.segment_table(good)
    assert rows[0][:3] == [0, "encouragement", "opening"] and len(rows) == 4
    seg_path, _ = app.render_segment(good, 1, "mock", None, config=MOCK_CFG, out_dir=tmp_path, cache=cache)
    assert seg_path and Path(seg_path).exists()
    assert app.render_segment(good, 99, "mock", None, config=MOCK_CFG, out_dir=tmp_path)[0] is None


def test_render_audio_reports_missing_engine_in_arabic(tmp_path):
    good = (Path(__file__).resolve().parent.parent / "examples" / "milestone.json").read_text(encoding="utf-8")
    path, files, note = app.render_audio(good, "cairo", None, config=MOCK_CFG, out_dir=tmp_path)
    assert path is None and files == [] and "المحرك" in note


# ---- voices tab -------------------------------------------------------------------
def test_voices_of_and_reference_upload(tmp_path):
    assert app.voices_of("mock")[0] == ["mock_female", "mock_male"]
    import numpy as np
    import soundfile as sf
    clip = tmp_path / "in.wav"
    sf.write(str(clip), np.zeros(2400, np.float32), 24000)
    msg = app.save_reference_voice(str(clip), "ماما صوت!", "كلام", voices_dir=tmp_path / "v")
    assert "تم حفظ" in msg and (tmp_path / "v" / "ماما_صوت.wav").exists()
    assert (tmp_path / "v" / "ماما_صوت.txt").read_text(encoding="utf-8") == "كلام"
    assert "ارفع" in app.save_reference_voice(None, "x")


def test_ui_builds_with_four_tabs():
    gr = pytest.importorskip("gradio")
    demo, _ = app.build_app()
    labels = [b.label for b in demo.blocks.values() if type(b).__name__ == "Tab"]
    assert labels == ["الروبوت", "المحرر", "الأصوات", "مكتبة الجمل"]
