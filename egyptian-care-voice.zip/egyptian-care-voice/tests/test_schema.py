import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from core.schema import Script, format_errors_ar

EX = Path(__file__).resolve().parent.parent / "examples"


@pytest.mark.parametrize("name", ["before_session_anxious", "bad_day", "milestone"])
def test_examples_valid(name):
    Script.model_validate(json.loads((EX / f"{name}.json").read_text(encoding="utf-8")))


def _base():
    return {
        "patient": {"name": "x", "gender": "male"},
        "phase": "night",
        "messages": [{"category": "comfort", "segments": [{"part": "core", "text": "كلام"}]}],
    }


def test_bad_phase_arabic_error():
    d = _base(); d["phase"] = "nope"
    with pytest.raises(ValidationError) as e:
        Script.model_validate(d)
    assert any("phase" in m for m in format_errors_ar(e.value))


def test_wrong_order_rejected():
    d = _base()
    d["messages"][0]["segments"] = [{"part": "closing", "text": "أ"}, {"part": "core", "text": "ب"}]
    with pytest.raises(ValidationError) as e:
        Script.model_validate(d)
    assert any("ترتيب" in m for m in format_errors_ar(e.value))


def test_missing_core_rejected():
    d = _base()
    d["messages"][0]["segments"] = [{"part": "opening", "text": "أ"}]
    with pytest.raises(ValidationError) as e:
        Script.model_validate(d)
    assert any("core" in m for m in format_errors_ar(e.value))


def test_bad_format_rejected():
    d = _base(); d["output_format"] = "ogg"
    with pytest.raises(ValidationError):
        Script.model_validate(d)
