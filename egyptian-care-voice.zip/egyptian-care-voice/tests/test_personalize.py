import pytest

from core.personalize import personalize_text


def test_name_and_gender_female():
    t = personalize_text("يا {name}، {انت|انتي} {قده|قدها}", "سارة", "female")
    assert t == "يا سارة، انتي قدها"


def test_gender_male():
    assert personalize_text("{معاك|معاكي}", "x", "male") == "معاك"


def test_unresolved_raises():
    with pytest.raises(ValueError):
        personalize_text("{foo}", "x", "male")
