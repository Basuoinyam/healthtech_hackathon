import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from types import SimpleNamespace

import pytest

from core import safety
from core.safety import (
    ESCALATION_LINE,
    MEDICAL_QUESTION_REPLY,
    ContentValidator,
    check_and_escalate,
    count_words,
    normalize_ar,
    split_sentences,
)

ROOT = Path(__file__).resolve().parent.parent
V = ContentValidator.from_file(ROOT / "data" / "blocked_phrases.json")
PATIENT = {"name": "أم أحمد", "gender": "female", "preferred_voice": "egyptian_female_1"}


def rules_hit(text, category="encouragement", part=None):
    return {v.rule for v in V.validate_text(text, category, part).violations}


# ---- normalization ---------------------------------------------------------
def test_normalize_strips_marks_and_folds_letters():
    assert normalize_ar("خلّينا نسأل الدُّكتور، أحمد!") == "خلينا نسال الدكتور احمد"
    assert normalize_ar("حاجة") == "حاجه"
    assert normalize_ar("٥٠٠ مجم") == "500 مجم"


def test_count_words_ignores_marks_and_punctuation():
    assert count_words("نرتاح شوية وبعدين نكمّل؟") == 4
    assert count_words("خد نفس براحة… أنا هنا معاك") == 6


def test_split_sentences_ellipsis_is_not_a_break():
    assert len(split_sentences("خد نفس براحة… أنا هنا معاك")) == 1
    assert len(split_sentences("جملة أولى. جملة تانية؟ تالتة!")) == 3


def test_rule_regexes_are_written_in_normalized_form():
    # Regex entries are matched against normalized text, so they must not
    # contain letters that normalization folds away (ة ى أ إ آ ئ ؤ).
    data = json.loads((ROOT / "data" / "blocked_phrases.json").read_text(encoding="utf-8"))
    for name, rule in data["rules"].items():
        for rx in rule.get("regex", []):
            assert rx == rx.translate(safety._FOLD), f"{name}: {rx}"


# ---- blocked content -------------------------------------------------------
@pytest.mark.parametrize("text", [
    "خد الدوا في معاده يا حبيبي",
    "ممكن تاخد حباية مسكن لو تعبان",
    "لازم تاخد ٥٠٠ مجم كل يوم",
    "خد جرعة زيادة النهارده",
    "وقف الدوا لو حاسس بتعب",
    "كل ٨ ساعات اتناول العلاج",
    "خد علاج من العطار",
    "مش لازم تروح للدكتور",
])
def test_medical_advice_and_dosage_rejected(text):
    hits = rules_hit(text)
    assert hits & {"medication_mention", "medical_advice"}, hits


@pytest.mark.parametrize("text", [
    "هتخف أكيد قريب",
    "إنت هتخف بإذن الله",
    "هتبقي كويسة وزي الفل",
    "مفيش حاجة تقلق",
    "العلاج هينجح",
    "أنا ضامن إنك هتشفى",
    "أكيد هتتحسن بسرعة",
    "هتتحسن أكيد",
])
def test_guaranteed_cure_rejected(text):
    assert "guaranteed_cure" in rules_hit(text)


@pytest.mark.parametrize("text", [
    "ماتزعلش يا حبيبي",
    "متخافش، كله هيعدي",
    "بص للجانب الحلو في الموضوع",
    "بلاش تقلق من حاجة",
    "في ناس أسوأ منك",
])
def test_toxic_positivity_rejected_in_comfort(text):
    assert "toxic_positivity" in rules_hit(text, category="comfort")


def test_toxic_positivity_rule_is_comfort_only():
    assert "toxic_positivity" not in rules_hit("ماتزعلش يا حبيبي", category="encouragement")


def test_prefixed_forms_are_caught():
    assert "medication_mention" in rules_hit("افتكر تاخد بالدوا")
    assert "guaranteed_cure" in rules_hit("وهتخف قريب")


def test_diacritics_and_tatweel_cannot_bypass():
    assert "guaranteed_cure" in rules_hit("هَتْخِـــف")
    assert "toxic_positivity" in rules_hit("مَاتِزْعَلْش", category="comfort")


@pytest.mark.parametrize("text", [
    "إحنا ماشيين في الطريق الصح",
    "كل خطوة بتفرق، وأنا معاك",
    "خد نفس براحة… أنا هنا معاك",
    "اللي انت حاسس بيه مفهوم، ومن حقك تزعل",
    "الوجع ده هيعدّي، ومش هتعدّيه لوحدك",
    "مش لازم تكون قوي طول الوقت",
    "كل يوم بتعدّيه هو انتصار",
    "خلّينا نسأل الدكتور",
])
def test_good_sentences_pass(text):
    r = V.validate_text(text, category="comfort")
    assert r.ok, r.reasons()


def test_rejection_has_arabic_reason_and_matched_text():
    r = V.validate_text("هتخف أكيد", "encouragement")
    assert not r.ok
    v = r.errors[0]
    assert v.rule == "guaranteed_cure" and v.matched and v.reason_ar
    assert any("الشفا" in s for s in r.reasons("ar"))
    assert r.reasons("en")


def test_formal_arabic_is_warning_not_error():
    r = V.validate_text("سوف نذهب معا إلى الجلسة بإذن الله", "positivity")
    assert r.ok
    assert [v.rule for v in r.warnings] == ["formal_arabic"]


# ---- length ----------------------------------------------------------------
def test_sentence_over_15_words_rejected():
    text = " ".join(["كلمة"] * 16)
    assert "sentence_too_long" in rules_hit(text)


def test_long_text_made_of_short_sentences_is_fine():
    text = "جملة قصيرة هنا. " * 6
    assert "sentence_too_long" not in rules_hit(text)


def test_exactly_15_words_ok():
    assert "sentence_too_long" not in rules_hit(" ".join(["كلمة"] * 15))


@pytest.mark.parametrize("part", ["opening", "acknowledgment", "core", "closing"])
def test_one_word_is_allowed_for_every_part(part):
    assert "segment_too_short" not in rules_hit("كلمة", part=part)


@pytest.mark.parametrize("part", ["opening", "acknowledgment", "core", "closing"])
def test_text_without_words_is_rejected(part):
    assert "segment_too_short" in rules_hit("… !", part=part)


# ---- templates, scripts, examples -----------------------------------------
def test_template_checks_both_gender_forms():
    ok = V.validate_template("{انت|انتي} {قده|قدها} وأنا {معاك|معاكي}", "encouragement", "core")
    assert ok.ok, ok.reasons()
    bad = V.validate_template("{هتخف|هتخفي} قريب {معاك|معاكي}", "encouragement", "core")
    assert not bad.ok
    assert {v.gender for v in bad.errors} == {"male", "female"}


def test_template_unresolved_placeholder_raises():
    with pytest.raises(ValueError):
        V.validate_template("كلام {foo} هنا", "comfort", "core")


@pytest.mark.parametrize("name", ["before_session_anxious", "bad_day", "milestone"])
def test_example_scripts_pass_for_both_genders(name):
    data = json.loads((ROOT / "examples" / f"{name}.json").read_text(encoding="utf-8"))
    for msg in data["messages"]:
        for seg in msg["segments"]:
            r = V.validate_template(seg["text"], msg["category"], seg["part"])
            assert r.ok, (name, seg["text"], r.reasons())


def test_validate_script_reports_location():
    script = SimpleNamespace(messages=[SimpleNamespace(category="comfort", segments=[
        SimpleNamespace(part="opening", text="أهلاً يا سارة"),
        SimpleNamespace(part="core", text="ماتزعلش يا سارة، هتخف قريب"),
    ])])
    r = V.validate_script(script)
    assert not r.ok
    assert {(v.message_index, v.segment_index) for v in r.errors} == {(0, 1)}
    assert {v.rule for v in r.errors} == {"toxic_positivity", "guaranteed_cure"}
    assert "[messages.0.segments.1]" in r.reasons()[0]


def test_validate_script_accepts_dicts():
    script = {"messages": [{"category": "comfort", "segments": [{"part": "core", "text": "أنا هنا معاك دايماً"}]}]}
    assert V.validate_script(script).ok


def test_fixed_lines_pass_the_validator():
    for line in (ESCALATION_LINE, MEDICAL_QUESTION_REPLY):
        r = V.validate_text(line, "comfort", "core")
        assert r.ok, (line, r.reasons())
        assert not r.warnings


def test_default_validator_loads():
    assert safety.get_validator().validate_text("أنا هنا معاك", "comfort").ok


# ---- patient input: medical questions and emergencies ----------------------
@pytest.mark.parametrize("text", [
    "هاخد الدوا امتى؟",
    "ينفع أخد مسكن دلوقتي",
    "الجرعة دي كام مرة في اليوم؟",
    "الأعراض دي معناها إيه",
])
def test_medical_questions_detected(text):
    assert V.is_medical_question(text)


@pytest.mark.parametrize("text", ["أنا تعبان النهارده", "عايز أسمع حاجة حلوة؟", "الدوا طعمه وحش"])
def test_non_questions_not_flagged(text):
    assert not V.is_medical_question(text)


@pytest.mark.parametrize("text", ["أنا بموت من الوجع", "عايز أموت", "مش قادر أتنفس", "حد يلحقني"])
def test_emergency_text_detected(text):
    assert V.find_emergency(text)


def test_normal_complaint_is_not_emergency():
    assert V.find_emergency("أنا تعبان شوية وعايز أرتاح") is None


# ---- escalation ------------------------------------------------------------
def test_no_escalation_for_normal_moods():
    for mood in (None, "good", "tired", "anxious", "sad"):
        assert check_and_escalate(PATIENT, "bad_day", mood, alerts_log="unused.log") is None


def test_pain_mood_escalates_and_logs(tmp_path):
    log = tmp_path / "logs" / "alerts.log"
    res = check_and_escalate(PATIENT, "during_session", "pain", alerts_log=log)
    assert res is not None and res.reason == "mood_pain"
    assert res.line == ESCALATION_LINE
    assert res.logged and not res.errors
    entry = json.loads(log.read_text(encoding="utf-8").splitlines()[-1])
    assert entry["level"] == "ALERT" and entry["reason"] == "mood_pain"
    assert entry["patient"] == "أم أحمد" and entry["phase"] == "during_session"
    assert entry["timestamp"]


def test_escalation_script_replaces_normal_script(tmp_path):
    res = check_and_escalate(PATIENT, "night", "pain", alerts_log=tmp_path / "a.log")
    msgs = res.script["messages"]
    assert len(msgs) == 1 and len(msgs[0]["segments"]) == 1
    assert msgs[0]["segments"][0]["text"] == ESCALATION_LINE
    assert res.script["patient"]["name"] == "أم أحمد"
    assert res.script["phase"] == "night"


def test_emergency_text_escalates(tmp_path):
    res = check_and_escalate(PATIENT, "bad_day", "sad", event_text="مش قادر أتنفس", alerts_log=tmp_path / "a.log")
    assert res is not None and res.reason == "emergency_text"


def test_alerts_are_appended_not_overwritten(tmp_path):
    log = tmp_path / "a.log"
    check_and_escalate(PATIENT, "night", "pain", alerts_log=log)
    check_and_escalate(PATIENT, "night", "pain", alerts_log=log)
    assert len(log.read_text(encoding="utf-8").splitlines()) == 2


def test_callback_receives_alert(tmp_path):
    got = []
    res = check_and_escalate(PATIENT, "night", "pain", alerts_log=tmp_path / "a.log", callback=got.append)
    assert res.notified and got and got[0]["reason"] == "mood_pain"


def test_failing_callback_does_not_block_logging_or_line(tmp_path):
    def boom(_alert):
        raise RuntimeError("down")

    log = tmp_path / "a.log"
    res = check_and_escalate(PATIENT, "night", "pain", alerts_log=log, callback=boom)
    assert res.logged and log.exists()
    assert not res.notified and any("callback failed" in e for e in res.errors)
    assert res.line == ESCALATION_LINE


def test_webhook_receives_alert(tmp_path):
    received = []

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            body = self.rfile.read(int(self.headers["Content-Length"]))
            received.append(json.loads(body.decode("utf-8")))
            self.send_response(200)
            self.end_headers()

        def log_message(self, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/alert"
        res = check_and_escalate(PATIENT, "night", "pain", alerts_log=tmp_path / "a.log", webhook_url=url)
    finally:
        server.shutdown()
    assert res.notified and not res.errors
    assert received and received[0]["reason"] == "mood_pain"


def test_unreachable_webhook_is_recorded_not_raised(tmp_path):
    res = check_and_escalate(PATIENT, "night", "pain", alerts_log=tmp_path / "a.log",
                             webhook_url="http://127.0.0.1:9/alert", webhook_timeout=0.5)
    assert res.logged and not res.notified
    assert any("webhook failed" in e for e in res.errors)


def test_non_http_webhook_rejected(tmp_path):
    res = check_and_escalate(PATIENT, "night", "pain", alerts_log=tmp_path / "a.log", webhook_url="file:///etc/passwd")
    assert not res.notified and any("webhook failed" in e for e in res.errors)
