# شرح المشروع: egyptian-care-voice

## 1. فكرة المشروع
روبوت مرافق لمريض في فترة العلاج، بيكلّمه بالعامية المصرية بصوت دافي. الرسالة بتتكتب كسكريبت JSON منظم وبعدين بتتحول لصوت. المشروع مبني على أدوات مجانية ومفتوحة المصدر بس، وفيه قواعد أمان بتتطبق في الكود (مش في الكلام بس).

## 2. إزاي بيشتغل (الصورة الكبيرة)
```
phase + mood -> [escalation لو pain] -> selector -> script JSON -> validate -> personalize -> safety -> preprocess -> TTS -> post-process -> assemble -> mp3 + timestamps.json
```
دلوقتي شغّال منها: validate و personalize و safety و escalation و selector (اختيار الجمل) وأمر speak. الباقي (الصوت) في المراحل الجاية.

## 3. عملت إيه بالظبط (جدول الملفات)
| الملف | الوظيفة | أهم الدوال |
|---|---|---|
| core/schema.py | نماذج Pydantic للسكريبت ورسائل الأخطاء بالعربي | Script, Message, Segment, Patient, format_errors_ar |
| core/placeholders.py | تبديل `{name}` وصيغ `{مذكر\|مؤنث}` من غير pydantic (علشان الـ safety والاختبارات) | resolve_placeholders |
| core/personalize.py | يغلّف placeholders على الـ Script | personalize_text, personalize_script |
| core/safety.py | فاحص المحتوى + الـ Escalation | ContentValidator (validate_text / validate_template / validate_script / is_medical_question / find_emergency), normalize_ar, check_and_escalate, escalate, needs_escalation, build_escalation_script, log_alert |
| core/selector.py | بيختار السكريبت حسب phase و mood: بيستدعي `check_and_escalate` الأول، وبعدين بيختار جمل من المكتبة من غير تكرار آخر 5 | select, select_script, load_library, load_recent |
| data/phrases.json | مكتبة الجمل: 268 جملة (20+ في كل خانة من 12 خانة، وفيها جمل الأمثلة بتاعة الـ Prompt) | - |
| data/selection_rules.json | جدول: كل phase و mood ياخدوا أنهي categories وأنهي أجزاء (بيتعدّل من غير كود) | - |
| data/blocked_phrases.json | قواعد المنع وحدود الطول وكلمات الطوارئ (بتتعدّل من غير ما تلمس الكود) | - |
| main.py | واجهة الأوامر (CLI) بنفس شكل الـ Prompt (`speak --phase ...`) | validate و speak (شغالين)، و generate و voices لسه |
| config.yaml | إعدادات الموديل والـ presets | - |
| examples/*.json | 3 سكريبتات أمثلة + ملف مريض | - |
| tests/test_schema.py, test_personalize.py, test_safety.py, test_selector.py | الاختبارات (214 اختبار) | - |

### تفاصيل safety.py
- `normalize_ar(text)`: بيشيل التشكيل والتطويل والحروف الخفية، ويوحّد (أ إ آ ← ا) و(ى ← ي) و(ة ← ه)، ويحوّل الأرقام العربي لإنجليزي، ويشيل الترقيم. كده "هَتْخِـــف" بتتمسك زي "هتخف".
- `ContentValidator.validate_text(text, category, part)`: يفحص نص واحد (بعد التخصيص) ويرجّع `SafetyResult` فيه `ok` وقايمة `violations` كل واحدة فيها القاعدة والجزء اللي اتمسك والسبب بالعربي والإنجليزي.
- `validate_template(text, category, part)`: لنصوص مكتبة الجمل اللي فيها `{}`، بيفحص صيغة المذكر والمؤنث الاتنين.
- `validate_script(script)`: يفحص سكريبت كامل ويقول المقطع اللي فيه المشكلة (`messages.0.segments.1`).
- `is_medical_question(text)` و`find_emergency(text)`: لكلام المريض نفسه.
- `check_and_escalate(patient, phase, mood, event_text, ...)`: نقطة الدخول للـ selector. بترجّع `None` لو كله عادي.

## 4. شرح كل مرحلة
### المرحلة 0 (خلصت)
هيكل الفولدرات و requirements.txt و config.yaml. قرار: موديلات الصوت الثقيلة (torch وغيره) في requirements-engines.txt منفصل، علشان التسطيب الأساسي يفضل خفيف والاختبارات تشتغل من غير تنزيل موديلات.
### المرحلة 1 (خلصت)
schema و personalize والأمثلة الثلاثة. ترتيب المقاطع (opening ثم acknowledgment ثم core ثم closing) والـ core الإجباري بيتفحصوا في الـ schema. أي placeholder مش متحلّ بيرفع خطأ.
### المرحلة 3 (خلصت): مكتبة الجمل والـ selector وأمر speak
**اتعمل:** `data/phrases.json` و`data/selection_rules.json` و`core/selector.py` وأمر `speak` في `main.py` و`tests/test_selector.py`.

**قرارات:**
1. **جدول الاختيار مطابق للبندين 3.3 و3.8 من الـ Prompt** (بعد ما الملف وصل وراجعته): من غير mood ← الفئة الأساسية للـ phase (during_session = comfort ثم encouragement، night = comfort ثم positivity، milestone = encouragement ثم positivity). `good` ← encouragement أو positivity حسب الـ phase (مبيطلعش comfort أبداً؛ ولو الـ phase هو bad_day بياخد positivity). `tired` ← comfort قصيرة (opening + core + closing). `anxious` و`sad` ← comfort كاملة ثم positivity خفيفة. `pain` ← escalation.
2. **كل رسالة 4 أجزاء** زي البند 3.2، إلا الصيغة القصيرة (opening + core + closing) اللي الـ Prompt نفسه حدّدها لـ `tired`. وكلمة "positivity خفيفة" بعد المواساة نفّذتها بنفس الصيغة القصيرة (لأنها الصيغة الوحيدة المختصرة المعرّفة في الـ Prompt). **ده تفسير مني**، ممكن تعدّله في `selection_rules.json`.
3. **الجمل مش مربوطة بوقت معيّن:** مفيش "صباح الخير" في الجمل، علشان أي خانة تنفع في أي phase. الروبوت بيتكلم بصيغة المذكر، والمريض بصيغة `{مذكر|مؤنث}`.
4. **كل جملة في المكتبة بتعدّي `validate_template`** بالصيغتين، وفيه اختبار بيفحص الملف كله. جمل الأمثلة بتاعة الـ Prompt (البند 3.6) وجمل "إحنا ماشيين في الطريق الصح" و"كل خطوة بتفرق" (البند 3.7) اتضافت للمكتبة. (مثال "شوف {وصلت|وصلتي}" اتصلّح لـ `{شوف|شوفي}` علشان الصيغة المؤنثة تطلع صح.)
5. **الـ selector بيبدأ بالـ escalation:** لو الـ mood هو pain أو الكلام فيه كلمة طوارئ، بيرجّع سكريبت الجملة الثابتة ومبيلمسش المكتبة خالص (فيه اختبار بمكتبة فاضية).
6. **من غير تكرار آخر 5 جمل:** الذاكرة في `.cache/recent_phrases.json`. ملف بايظ بيتعامل معاه كأنه فاضي. لو الخانة صغيرة جداً بيرجّع أقدم جملة اتقالت (مش اللي لسه متقالة؛ ده كان عيب اتصلّح بعد ما اختبار كشفه).
7. **الـ preset** (سرعة، مشاعر، وقفة) من `config.yaml` في كل مقطع، وآخر مقطع وقفته 0. `exaggeration` مش في الـ schema فمبيتطلعش في الـ JSON.
8. **`speak` بنفس شكل الـ Prompt:** `python main.py speak --phase before_session --mood anxious --patient examples/patient.json`. بيطلّع JSON بس على stdout، والسكريبت بيتفحص بالـ schema قبل الطباعة. `--personalized` بيحلّ الأسماء والصيغ وبيشغّل فاحص الأمان تاني.

**مشاكل حصلت واتحلت:** في أول نسخة كان الـ `speak` بياخد الـ phase من غير `--phase` وكان جدول الاختيار تصميم مني (لأن ملف الـ Prompt ماكانش وصل). لما وصل اتقارن واتصلّح الاتنين.

### المرحلة 2 (خلصت، مع ملاحظة التحقق تحت)
**اتعمل:** `core/safety.py` و`data/blocked_phrases.json` و`tests/test_safety.py` و`core/placeholders.py`.

**قرارات:**
1. **القواعد في JSON مش في الكود:** علشان تقدر تضيف كلمة ممنوعة من غير ما تعدّل Python. كل قاعدة ليها `severity` (error يرفض، warning يحذّر بس).
2. **التطبيع قبل المقارنة:** من غير كده التشكيل أو "ة/ه" كانوا هيعدّوا الكلمة الممنوعة.
3. **المقارنة على الكلمة كاملة مش جزء منها:** "هتخف" بتتمسك لكن مش جوه كلمة تانية. وبتتمسك كمان لو ملصوق قدامها (و، ب، ل، ف، ك) زي "وهتخف" و"بالدوا".
4. **ليه كلمة "دوا" وأخواتها ممنوعة خالص مش بس "خد الدوا":** الـ Prompt بيقول "ممنوع أي كلام عن أدوية أو جرعات". فالقاعدة الأوسع هي الأكتر أمان. الكلمة "علاج" نفسها مش ممنوعة لأنها جزء طبيعي من الكلام ("فترة العلاج").
5. **"ماتزعلش" وأخواتها ممنوعة في `comfort` بس**، زي ما الـ Prompt قال. في encouragement مسموحة (فيه اختبار بيثبّت ده).
6. **الجمل الفصحى (سوف، ماذا، لماذا...) تحذير مش رفض:** علشان مايحصلش رفض غلط لكلمة عادية.
7. **الـ escalation بيفضّل الإنذار الزيادة:** لو المريض قال "مش عايز أموت" هيتمسك برضو (الإنذار الكاذب أكتر أمان من إنذار فايت).
8. **اللوج والـ callback والـ webhook مستقلين:** لو واحد وقع، الباقي بيكمّل وجملة التهدئة بتتقال برضو. الأخطاء بتتسجّل في `errors` ومبترميش exception.
9. **الـ webhook بيقبل http/https بس.** واللي بيتبعت هو نفس سطر اللوج.

**قرار حدود الطول (اتأكد من المستخدم):** أي مقطع من **كلمة واحدة لحد 15 كلمة**. يعني:
- **الحد الأقصى 15 كلمة للجملة الواحدة** (الجملة بتتقسّم عند . ! ? ؟ وسطر جديد، و"…" مش بتقسّم).
- **الحد الأدنى كلمة واحدة** لكل مقطع (في `min_words_per_segment` لكل الأجزاء الأربعة)، فنص من غير ولا كلمة (علامات ترقيم بس) بيترفض.
- ده بدل "من 6 لـ 15" اللي في البند 3.7 من الـ Prompt، بقرار من المستخدم. لو عايز تغيّره عدّل `length` في `data/blocked_phrases.json`.

**مشاكل حصلت واتحلت:**
- أمثلة المرحلة 1 فيها أخطاء صغيرة اتصلحت: في milestone كان `{وصلتي|وصلتي}` (صيغة المذكر غلط) وكلمة "شوفي" مكتوبة للمؤنث بس، فبقت `{شوف|شوفي} {وصلت|وصلتي}`. وفي before_session_anxious بقت `{تحب|تحبي}`.
- لو كتبت regex في JSON بحروف زي "ة" أو "أ" مش هيشتغل (لأن النص بيتطبّع الأول). فيه اختبار بيتأكد إن كل الـ regex مكتوبة بالشكل المطبّع.

**ملاحظة التحقق:** المرحلة دي اتكتبت أول مرة في بيئة من غير pytest. في بداية المرحلة 3 اتشغّل **pytest الحقيقي** (مع pydantic و typer) وطلع **83 اختبار عدّوا** (10 + 73)، فمعيار المرحلة 2 اتحقق فعلاً.

## 5. تصميم الكلام
**المكتبة:** 3 categories (encouragement, positivity, comfort) × 4 أجزاء (opening, acknowledgment, core, closing) = 12 خانة، في كل واحدة 20 جملة أو أكتر (المجموع 268).

**الجدول (من البند 3.3 و3.8، في `selection_rules.json`):** كل رسالة 4 أجزاء.
| الـ phase | من غير mood | mood = good |
|---|---|---|
| morning_checkin | positivity | positivity |
| before_session | encouragement | encouragement |
| during_session | comfort ثم encouragement | encouragement |
| after_session | encouragement | encouragement |
| bad_day | comfort | positivity |
| milestone | encouragement ثم positivity | encouragement ثم positivity |
| night | comfort ثم positivity | positivity |

**حسب الـ mood** (بيغلب الجدول): `tired` = comfort قصيرة (opening + core + closing) بس، `anxious` و`sad` = comfort كاملة ثم positivity خفيفة (opening + core + closing)، `pain` = escalation مباشرة.

**أسلوب الكتابة:** جمل قصيرة بالعامية، بدون وعود أكيدة وبدون كلام عن أدوية، وفي المواساة مفيش "ماتزعلش/ماتخافش" (بتلغي المشاعر). مثال على جملة بصيغتين: `{خد|خدي} نفس براحة… أنا هنا {معاك|معاكي}`.

**قبل ما تعتمد أي جملة للاستخدام الحقيقي:** يفضل راجعها حد بيتكلم مصري كلغة أم (النبرة والصيغ).

## 6. قواعد الأمان
| القاعدة (من الـ Prompt 3.7) | بتتطبق فين | إزاي تختبرها |
|---|---|---|
| 1. ممنوع نصيحة طبية أو دوا أو جرعات | `ContentValidator` قواعد `medication_mention` و`medical_advice`. الرد الثابت `MEDICAL_QUESTION_REPLY` = "ده سؤال مهم، خلّينا نسأل الدكتور"، و`is_medical_question()` بتكتشف السؤال | `pytest tests/test_safety.py -k "medical or dosage"` |
| 2. ممنوع وعود أكيدة بالشفا | قاعدة `guaranteed_cure` (هتخف، مفيش حاجة، العلاج هينجح، "أكيد هتتحسن"...) | `-k guaranteed` |
| 3. ممنوع toxic positivity في المواساة | قاعدة `toxic_positivity` بتشتغل على `comfort` بس | `-k toxic` |
| 4. جمل قصيرة بالعامية | `_check_length` (أقصى 15 كلمة، أدنى حسب الجزء) + تحذير `formal_arabic` | `-k "length or sentence or formal"` |
| 5. Escalation | `check_and_escalate` / `escalate`: بتوقف السكريبت العادي وتطلّع سكريبت من مقطع واحد بالجملة الثابتة "أنا سامعك، وهبلّغ الدكتور أو الممرضة دلوقتي حالاً"، وتسجّل في `logs/alerts.log` (سطر JSON لكل إنذار)، وتبعت callback أو webhook لو اتحدد | `-k "escalat or pain or webhook or callback"` |
| 6. Content Validator بسبب الرفض | `SafetyResult.reasons("ar")` فيها السبب والكلمة اللي اتمسكت | `-k reason` |
| 7. مستوى الصوت وfade-in | **لسه** (المرحلة 5، `audio.py`) | - |

**مثال استخدام من Python:**
```python
from core.safety import get_validator, check_and_escalate
r = get_validator().validate_text("هتخف أكيد قريب يا سارة", "encouragement", "core")
print(r.ok, r.reasons())   # False ['ممنوع الوعود الأكيدة بالشفا (هتخف)']
esc = check_and_escalate({"name": "أم أحمد", "gender": "female"}, "night", mood="pain")
print(esc.line)            # أنا سامعك، وهبلّغ الدكتور أو الممرضة دلوقتي حالاً
```

## 7. التسطيب والتشغيل
```
pip install -r requirements.txt            # الأساسيات + الواجهة + الاختبارات
python -m pytest -q                         # 288 اختبار ناجح + اختبار واحد skipped (من غير تنزيل موديل)
python main.py validate examples/milestone.json
python main.py generate examples/bad_day.json --engine mock --out outputs/bad_day_mock.mp3   # من غير موديل
```
**للصوت الحقيقي (VoiceTut-TTS، المحرك الافتراضي):** ثبّت torch المناسب من pytorch.org، وبعدين `pip install -r requirements-engines.txt` (بيثبّت OmniVoice من GitHub و voicetut-tts). الأوزان بتتنزّل تلقائياً أول مرة من HuggingFace، فمحتاج إنترنت. بعدها:
```
python main.py voices --engine voicetut
python main.py generate examples/bad_day.json --out outputs/bad_day.mp3
python app.py        # الواجهة على http://127.0.0.1:7860
```
**ffmpeg:** لازم لتصدير MP3. على Linux: `sudo apt install ffmpeg`. على Windows: حط `ffmpeg.exe` في جذر المشروع أو على الـ PATH (المشروع بيستخدمه تلقائياً على Windows بس).

## 8. أمثلة الاستخدام
`python main.py validate examples/bad_day.json` ← `OK: 1 message(s), 4 segment(s).`
`python main.py speak --phase after_session --mood anxious --personalized` ← سكريبت JSON جاهز بجمل جديدة كل مرة.
`python main.py speak --phase night --mood pain` ← سكريبت الجملة الثابتة، والإنذار بيتسجّل في `logs/alerts.log`، والـ exit code = 0.
`python main.py speak --phase bad_day --seed 7 --no-memory` ← نفس النتيجة كل مرة (للتجربة).

## 9. إزاي أعدّل أو أضيف
**أضيف كلمة أو عبارة ممنوعة:** افتح `data/blocked_phrases.json` وضيفها في `phrases` تحت القاعدة المناسبة (اكتبها عادي، بتتطبّع تلقائي). لو بتكتب `regex` اكتبها بالحروف المطبّعة (ا ي ه بدل أ ى ة).
**أعدّل حدود الطول:** `length` في نفس الملف.
**أضيف جملة للمكتبة:** افتح `data/phrases.json`، ضيفها في الخانة (category ثم part). استخدم `{name}` للاسم و`{مذكر|مؤنث}` للصيغ (المذكر الأول). بعدها شغّل `python -m pytest -q tests/test_selector.py`، لو الجملة مرفوضة الاختبار هيعرض السبب.
**أغيّر اختيار الرسالة لـ phase أو mood:** عدّل `data/selection_rules.json` (قايمة `category` و`parts` لكل واحد).
**أغيّر عدد الجمل اللي مابتتكررش:** `recent_memory_size` في `config.yaml`. لمسح الذاكرة امسح `.cache/recent_phrases.json`.
**أضيف صوت جديد:** من تاب «الأصوات» ارفع مقطع صوتي مرجعي واكتب له اسم (ويفضل تكتب نص الكلام المسجّل). بيتحفظ في `voices/<الاسم>.wav` ويظهر في قايمة أصوات voicetut.
**أغيّر المحرك الافتراضي:** `default_engine` في `config.yaml` (voicetut أو cairo أو mock)، أو `--engine` في الأمر.
**أملأ قاموس النطق:** `data/pronunciation.json` عبارة عن `{"كلمة": "النطق المطلوب"}`، وهو فاضي حالياً لحد ما متحدث مصري يراجعه.

## 10. حدود الموديلات ورخصها
VoiceTut-TTS (الافتراضي): ترخيص Apache-2.0 حسب بيانات الحزمة، ومبني على OmniVoice، وبيشتغل على CPU أو GPU (على CPU هيكون أبطأ بكتير، والمؤلف قاس RTF حوالي 1.13 على T4). Cairo-TTS: الكود MIT والأوزان بشروط Kyutai. NAMAA: MIT. Nile-XTTS: غير تجاري. راجع ترخيص كل موديل قبل أي استخدام تجاري.

## 11. المشاكل المعروفة
- **جملة سليمة اترفضت:** شوف `reasons()`. غالباً كلمة زي "دوا" أو "هتخف" جوه الجملة. القواعد مقصودة تكون واسعة (أكتر أمان). لو شايف إن كلمة مش لازم تتمنع، شيلها من JSON.
- **Escalation على جملة مش مقصودة:** ("مش عايز أموت" بتتمسك) مقصود، الإنذار الكاذب أكتر أمان.
- **`speak` طلّع جمل مش عاجباني:** عدّل أو امسح الجملة من `data/phrases.json` (مش لازم تعدّل كود).
- **نفس الجملة بترجع بعد فترة:** طبيعي، الذاكرة بتمنع تكرار آخر 5 جمل بس.
- **`Unknown phase or mood`:** الـ phase واحد من morning_checkin, before_session, during_session, after_session, bad_day, milestone, night. والـ mood واحد من good, tired, anxious, sad, pain.
- **`Missing option '--phase'`:** الـ phase بيتكتب بـ `--phase` (زي الـ Prompt) مش لوحده.
- **`ModuleNotFoundError: pydantic/typer/pytest`:** نفّذ `pip install -r requirements.txt`.
- **لو الـ webhook مبيوصلش:** بيتسجّل في `EscalationResult.errors`، واللوج في `logs/alerts.log` بيتكتب برضو.

- **`VoiceTut-TTS is not installed`:** ثبّت torch ثم `pip install -r requirements-engines.txt`. الرسالة دي مقصودة بدل traceback.
- **MP3 مش بيتصدّر:** ffmpeg مش موجود (شوف قسم 7)، أو استخدم `--out something.wav`.
- **الصوت `egyptian_female_1` مش موجود في محرك تاني:** بيتبدل بالصوت الافتراضي مع تحذير.
- **الصوت الحقيقي لسه ما اتجربش هنا:** كل الاختبارات بالـ Mock Engine والـ adapter بتاع VoiceTut متراجع على كود الحزمة المنشورة (0.1.1) لكن ما اتشغّلش بالأوزان الحقيقية في بيئة التطوير (مفيش وصول لـ HuggingFace). شغّل `generate` مرة على جهازك وراجع النتيجة بنفسك.
- **تغيير السرعة:** VoiceTut بيستقبل `speed` مباشرة. المحركات اللي مفيهاش سرعة (زي Cairo) بتتعدّل بـ WSOLA في `core/audio.py`.

## 12. أفكار للتطوير
STT، ربط هاردوير، دعم أكتر من مريض. وكمان: كشف الألم من نبرة الصوت، ومراجعة قايمة المنع مع دكتور أو أخصائي نفسي.

## 13. Changelog
- المرحلة 0 و1: الهيكل والـ schema والتخصيص وأمر validate، و10 اختبارات.
- المرحلة 2: `core/safety.py` (فاحص المحتوى + Escalation) و`data/blocked_phrases.json` و`core/placeholders.py` و`tests/test_safety.py` (73 حالة). تعديل `personalize.py` ليستخدم `placeholders.py` بنفس السلوك. تصحيح أمثلة milestone و before_session_anxious (صيغ المذكر والمؤنث).
- المرحلة 3: `data/phrases.json` و`data/selection_rules.json` و`core/selector.py` وأمر `speak` و`tests/test_selector.py`. بعد وصول ملف الـ Prompt: الجدول اتطابق مع 3.3 و3.8، `speak` بقى بـ `--phase`، الرسائل بقت 4 أجزاء، وحدود الطول بقت 1 لـ 15 كلمة بقرار المستخدم، وجمل الأمثلة اتضافت (268 جملة)، وعيب في اختيار الجملة عند الخانات الصغيرة اتصلّح. pytest الحقيقي: 214 اختبار عدّوا.

## المرحلة 4: محركات الصوت (تنفيذ مبدئي)
- engines/base.py يعرّف TTSEngine وواجهته: list_voices وsynthesize وsupports.
- engines/mock_engine.py يوفّر صوتاً اصطناعياً حتمياً باستخدام NumPy، بطول تقريبي حسب النص، للاختبارات والعمل دون تنزيل نموذج.
- engines/cairo_engine.py يحمّل Cairo-TTS عند الحاجة فقط، ويحوّل ملف WAV الناتج إلى مصفوفة mono وsample rate. لا يحمّل الأوزان عند استيراد المشروع أو عند عرض قائمة الأصوات.
- main.py voices --engine mock يعرض أصوات Mock. عند غياب cairo-tts تظهر رسالة تثبيت واضحة بدل traceback.
- voicetut وnamaa وnile-xtts مسجلة برسائل تثبيت اختيارية؛ دعم التوليد لهذه المحركات غير منفذ في هذه المرحلة.
- واجهة Cairo-TTS المستخدمة موثقة في README/PyPI: https://pypi.org/project/cairo-tts/ (التحميل عبر CairoTTS.from_pretrained، التوليد إلى ملف عبر save(..., voice=...)، وعرض الأصوات عبر 20 معرفاً موثقاً). واجهة VoiceTut راجعت من https://github.com/MohammedAly22/VoiceTuT-TTS/blob/main/README.md. واجهتا NAMAA وNile راجعتا من بطاقتي النموذج: https://huggingface.co/NAMAA-Space/NAMAA-Egyptian-TTS وhttps://huggingface.co/KickItLikeShika/NileTTS-XTTS.
- تحكم السرعة والانفعال غير مدعوم مباشرة في Cairo بحسب واجهته المنشورة؛ يجب معالجة السرعة في الـ post-processing في المرحلة 5.
- تحديث المرحلة 4: اختبار pytest الحقيقي عدّى (222 اختباراً)، وأمر voices للـ Mock نجح. محركات VoiceTut وNAMAA وNile تعرض إرشادات التثبيت فقط حالياً؛ توليد الصوت بها لسه محتاج adapters منفصلة.

## المرحلة 5: الـ Pipeline والصوت (خلصت)
| الملف | الوظيفة |
|---|---|
| core/preprocess.py | تنضيف النص، تحويل الأرقام لكلام مصري (حتى 999,999، وبعدها بتتقرا رقم رقم)، قاموس النطق `data/pronunciation.json` (فاضي حالياً، محتاج مراجعة متحدث مصري)، وتقسيم الجمل الطويلة (الحد من `config.yaml` → `preprocess.max_chunk_words`). |
| core/audio.py | fade-in/out بشكل نصف cosine، توحيد مستوى الصوت لكل مقطع على -23 LUFS بـ pyloudnorm مع سقف للـ peak، تغيير السرعة بـ WSOLA لو المحرك مش بيدعمها، وتصدير mp3/wav بـ pydub وffmpeg. |
| core/cache.py | cache بالـ hash لـ (النص + الصوت + المحرك + الباراميترات)، بيخزّن ناتج المحرك الخام كـ WAV float32 في `.cache/audio`. الملف التالف بيتعامل كـ miss. |
| core/pipeline.py | `run_pipeline`: validate ← personalize ← validate_script (بيرفض قبل أي توليد) ← preprocess ← synthesis بالـ cache ← post-process ← assembly بـ pydub ← export + `timestamps.json`. |
| main.py generate | `python main.py generate examples/bad_day.json --engine mock --out outputs/bad_day.mp3` (خيارات إضافية: `--voice`, `--no-cache`). |

- ملف التوقيتات بيتكتب جنب الصوت باسم `<اسم الصوت>.timestamps.json` وفيه بداية ونهاية كل مقطع ونصه (بعد التخصيص) وفئته وجزؤه والصوت.
- الصوت اللي مش موجود في المحرك (زي `egyptian_female_1` مع الـ mock) بيتبدّل بالصوت الافتراضي مع تحذير.
- الفاصل بين الرسائل `pause_between_messages_ms` = 1200ms، وبعد كل مقطع `pause_after_ms` من الـ segment أو من الـ preset.
- سكريبت الـ escalation بيتحوّل لصوت زي أي سكريبت (فيه اختبار).
- اللي لسه ما اتجربش: **Cairo-TTS الحقيقي**، لأن البيئة اللي اتختبر فيها مفيهاش الموديل. كل الاختبارات والتشغيل اتعملوا بالـ Mock Engine.

- تحديث المرحلة 5: 263 اختبار بيعدّوا (41 جديد: preprocess وaudio وpipeline_mock). الأمر `generate` اشتغل مع الـ mock وطلّع MP3 و timestamps، والتشغيل التاني استخدم الـ cache بالكامل.

## المرحلة 6: الواجهة (خلصت)
`app.py` (Gradio، اتجاه RTL عن طريق CSS وسكريبت `dir=rtl`)، وكل منطقها في دوال عادية (علشان الاختبار من غير تشغيل الواجهة). التابات الأربعة:
- **الروبوت:** اسم ونوع المريض والمرحلة والمزاج ← «ولّد رسالة» (نص للمراجعة + JSON) ← «شغّل الصوت». لو المزاج ألم بيظهر تنبيه التصعيد.
- **المحرر:** محرر JSON، زرار «تحقق» (شكل + أمان بالعربي)، جدول المقاطع، تشغيل مقطع لوحده، وتوليد الملف النهائي للتحميل (الصوت + timestamps).
- **الأصوات:** اختيار المحرك والصوت، ورفع صوت مرجعي للاستنساخ بيتحفظ في `voices/`.
- **مكتبة الجمل:** عرض وإضافة وتعديل وحذف لكل فئة وجزء. أي جملة جديدة أو معدّلة بتعدّي على `validate_template` وبتترفض (ومابتتكتبش في `data/phrases.json`) لو مخالفة. والحذف ممنوع لو الخانة هتقل عن 20 جملة.
تم التأكد إن الواجهة بتفتح على `http://127.0.0.1:7860` وإن تدفق «ولّد رسالة ← شغّل الصوت» اشتغل من خلال الواجهة بالـ Mock Engine.

## محرك VoiceTut (الافتراضي دلوقتي)
`engines/voicetut_engine.py`. اتراجع على كود حزمة `voicetut-tts` 0.1.1 المنشورة على PyPI (المصدر: https://pypi.org/project/voicetut-tts/ و https://github.com/MohammedAly22/VoiceTuT-TTS). المحرك بيمرر `speed` مباشرة، وبيختار float32 على CPU وfloat16 على GPU. **تصحيح بعد التجربة الفعلية:** قائمة الأصوات في الحزمة لم تطابق أوزان الموديل المحمّلة؛ الـ model نفسه أعلن 19 اسم متحدث، واعتمدنا الأسماء دي في الـ adapter.
- 12 صوت رجالي: Ahmed, Ali, Hassan, Karim, Mahmoud, Mohammed, Mostafa, Ramy, Shaker, Tareq, Yehia, Youssef؛ و7 أصوات نسائية: Hadeer, Hanan, Mariam, Rana, Sarah, Yasmin, Yara. `Hossam` و`Mohamed` مش موجودين في قائمة الوزن اللي اتجرب.
- أسماء المشروع: `egyptian_male_1` ← Ahmed، و`egyptian_female_1` ← Hanan. **قرار ممكن تغيّره** من `DEFAULT_ALIASES` في الملف. الصوت الافتراضي (لو مفيش اختيار) هو `egyptian_male_1` لأن الروبوت بيتكلم بصيغة المذكر.
- الاستنساخ: أي `voices/<name>.wav` (ومعاه `<name>.txt` اختياري) بيظهر كصوت.
- مفيش تحكم في الانفعال (emotion)، فالـ presets بتأثر على السرعة والوقفات بس.

## المرحلة 7 و8: الاختبارات والتوثيق (خلصت)
`pytest` كله بيعدّي: **288 اختبار ناجح واختبار واحد skipped** (بما فيهم test_preprocess وtest_pipeline_mock وtest_audio وtest_app وtest_voicetut_engine). اتضاف `README.md`، وفي `outputs/` عينات Mock للتجارب، وكمان عينة VoiceTut حقيقية اتولدت على GPU.
- إصلاح: كان فيه اختبار بيفرض `ffmpeg.exe` فبيفشل على Linux. دلوقتي `core/audio.py: configure_ffmpeg()` بيختار ffmpeg النظام، وعلى Windows بس بيرجع لـ `ffmpeg.exe` في جذر المشروع.

- تحديث نهائي: المراحل 0 لـ 8 اتنفذت. في تحقق 2026-11-21 النتيجة كانت **288 اختبار عدّت و1 اتخطاه**؛ وحصل فحص للكود وVoiceTut adapter، وإنشاء عينات mock قابلة للتشغيل في `outputs/`.
- إصلاح إضافي: `core/audio.py` يدعم fallback عبر حزمة `imageio-ffmpeg` بعد فحص `ffmpeg` النظام و`ffmpeg.exe` المحلي، علشان تصدير MP3 يشتغل على ويندوز من غير نسخة يدويّة جوه المشروع. و`requirements.txt` بقى يتطلب الحزمة.
- محرك VoiceTut بيتفعل كافتراضي في `config.yaml` و`engines/registry.py`. `list_voices()` لا يحمل الموديل، وسنتزيس بيستخدم الـ API الحقيقي `VoiceTutTTS.from_pretrained` ومرور `speaker/ref_audio/ref_text/language/speed`. ملف مرجعي من غير نص اختياري لم يعد يمرر `ref_text=None`.
- عشان يشتغل من أول مرة على جهاز فيه NVIDIA، اتعمل سكربت `setup_gpu.ps1` يفحص الكارت ونسخة CUDA ويثبت PyTorch/torchaudio المطابقين، واختبار مصفوفة صغير على CUDA. `requirements-engines.txt` مثبت عليه PyTorch وtorchaudio بإصدار CUDA 12.6، علشان يدعم معمارية Pascal sm_61 الخاصة بـ Quadro P2000.
- اتعمل التحقق من السكربت في 2026-11-21 على Quadro P2000: PyTorch `2.7.1+cu126` وCUDA available ونجح matrix multiplication. تشغيله على Windows: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File setup_gpu.ps1`.
- تصحيح بعد تحميل الأوزان الفعلية: موديل VoiceTut أعلن 19 صوتاً مختلفاً عن قائمة package README؛ تم تعديل `BUILTIN_SPEAKERS` والـ aliases إلى الأصوات الصالحة (Ahmed وHanan كأصوات المشروع الافتراضية). `Mohammed` موجود و`Hossam` غير موجود في الوزن المحمّل.
- تشغيل حقيقي على NVIDIA Quadro P2000 (sm_61): نسخة PyTorch cu128 الحديثة تعرّفت على الكارت لكنها لم تدعم معمارية Pascal. تم تثبيت PyTorch وtorchaudio `2.7.1+cu126`؛ اختبار CUDA matrix multiplication نجح. الأمر `python main.py generate examples/bad_day.json --engine voicetut --voice egyptian_male_1 --out outputs/bad_day_voicetut.wav --no-cache` نجح وأنتج صوت WAV حقيقياً بمعدل 24 kHz ومدته 13.11 ثانية، مع `outputs/bad_day_voicetut.timestamps.json`.
- اتعمل تحويل عينة VoiceTut الحقيقية إلى MP3 بمعدل تشفير 128k: `outputs/bad_day_voicetut.mp3`، وملف التوقيتات بقى يشير إلى الاسم ده.
- الواجهة، الاختبارات، والـ docs اتكملوا. اللي لسه محتاج منك: تشغيل الصوت الحقيقي مرة على جهازك، ومراجعة قايمة المنع مع متخصص، ومراجعة الجمل (268) مع متحدث مصري، وملء `pronunciation.json`.
