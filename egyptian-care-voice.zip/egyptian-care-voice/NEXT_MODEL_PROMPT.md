# Prompt للموديل اللي هيكمّل (انسخه كله كرسالة أولى + أرفق الـ zip)

أنت بتكمّل مشروع `egyptian-care-voice` (روبوت مرافق لمريض بيتكلم بالعامية المصرية، TTS مجاني ومفتوح المصدر). المراحل **0 لـ 8 خلصت** والمحرك الافتراضي VoiceTut-TTS.

## اقرا الأول (بالترتيب)
1. `egyptian_tts_robot_prompt.md`: المواصفات الأصلية (مصدر الحقيقة).
2. `HANDOFF.md`: الحالة والقرارات وقسم USER DECISIONS (الجمل من 1 لـ 15 كلمة) وقسم "What the user still has to do".
3. `project_exolanition.md`: الشرح بالعربي (لازم تحدّثه وتحدّث الـ Changelog).

## الخطوة الأولى الإجبارية
`pip install -r requirements.txt` ثم `python -m pytest -q`. آخر تحقق: **288 passed, 1 skipped**؛ أعد تشغيل الاختبارات وحدث الرقم إذا تغير. لو في فشل صلّحه الأول. ماتقولش إن الاختبارات نجحت من غير ما تشوفها.

## القواعد
- الكود والتعليقات والـ docstrings ورسائل الـ CLI بالإنجليزي. الشرح للمستخدم بالعامية المصرية. المحتوى العربي اللي هو المنتج (رسائل الخطأ، phrases.json، جملة التصعيد، الشرح) يفضل عربي.
- أدوات مجانية ومفتوحة بس. ماتخمنش API أي مكتبة: اقرا الـ README/المصدر الرسمي وسجّل المصدر في `project_exolanition.md`.
- استخدم `core/safety.py` و`core/pipeline.py` و`core/selector.py` زي ما هي (راجع الـ API في HANDOFF).
- `ffmpeg.exe` مش جوه الـ zip (المستخدم عنده نسخته). ماتضيفوش.
- حدّث `HANDOFF.md` و`project_exolanition.md` بعد أي شغل، ولو الجلسة قربت تخلص حدّثهم فوراً.

## المطلوب لو المستخدم رجّع نتيجة تشغيل حقيقي
لو رجّع traceback من `generate` بـ voicetut: صلّح `engines/voicetut_engine.py` وأضف اختبار. لو طلب، اعمل adapters حقيقية لـ NAMAA وNile-XTTS (ملفات `namaa_engine.py` و`xtts_engine.py` حسب الـ Prompt) بعد قراية بطاقة كل موديل.
