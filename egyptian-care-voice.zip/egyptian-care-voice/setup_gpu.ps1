Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

Write-Host "Egyptian Care Voice - CUDA setup" -ForegroundColor Cyan

$python = (Get-Command python -ErrorAction Stop).Source
& $python -c "import torch; print('Torch:', torch.__version__); print('CUDA available:', torch.cuda.is_available()); print('CUDA build:', torch.version.cuda); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'none')"

$needsCudaBuild = & $python -c "import torch, torchaudio; ok=torch.cuda.is_available() and '+cu126' in torch.__version__ and '+cu126' in torchaudio.__version__; raise SystemExit(0 if ok else 1)"
if ($LASTEXITCODE -ne 0) {
    Write-Host "Installing the verified CUDA 12.6/Pascal-compatible PyTorch pair..." -ForegroundColor Yellow
    & $python -m pip install --user --upgrade --force-reinstall --no-deps `
        torch==2.7.1+cu126 torchaudio==2.7.1+cu126 `
        --index-url https://download.pytorch.org/whl/cu126
    if ($LASTEXITCODE -ne 0) { throw "PyTorch CUDA installation failed." }
}

& $python -c "import torch; x=torch.randn((512,512),device='cuda'); y=x@x; torch.cuda.synchronize(); print('CUDA compute OK:', tuple(y.shape)); print('GPU:', torch.cuda.get_device_name(0)); print('Capability:', torch.cuda.get_device_capability(0))"
if ($LASTEXITCODE -ne 0) { throw "CUDA compute verification failed." }

Write-Host "CUDA setup verified." -ForegroundColor Green
