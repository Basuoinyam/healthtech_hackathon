"""Gradio web UI (RTL, Arabic) for egyptian-care-voice. Spec section 6, UI part.

All logic lives in plain functions so tests can run without launching Gradio;
``build_app`` imports gradio lazily.  Run with:  python app.py
"""
from __future__ import annotations

import json
import random
import re
import tempfile
from pathlib import Path
from typing import Any, Optional

from pydantic import ValidationError

from core.audio import ExportError
from core.cache import AudioCache
from core.pipeline import SafetyRejection, run_pipeline
from core.personalize import personalize_script
from core.placeholders import resolve_placeholders
from core.safety import get_validator
from core.schema import Category, Gender, Mood, Part, Patient, Phase, Script, format_errors_ar
from core.selector import DEFAULT_PHRASES_PATH, load_config, load_library, resolve_path, select
from engines import EngineError, get_engine, list_engines

PHASE_LABELS = {
    "morning_checkin": "صباح الخير (متابعة الصبح)", "before_session": "قبل الجلسة",
    "during_session": "أثناء الجلسة", "after_session": "بعد الجلسة",
    "bad_day": "يوم صعب", "milestone": "إنجاز", "night": "قبل النوم",
}
MOOD_LABELS = {"": "بدون (حسب المرحلة)", "good": "كويس", "tired": "تعبان", "anxious": "قلقان",
               "sad": "حزين", "pain": "ألم"}
CATEGORY_LABELS = {"encouragement": "تشجيع", "positivity": "إيجابية", "comfort": "مواساة"}
PART_LABELS = {"opening": "افتتاحية", "acknowledgment": "اعتراف بالشعور", "core": "الرسالة الأساسية",
               "closing": "ختام"}
UI_OUTPUT_DIR = Path("outputs") / "ui"
_SAFE_NAME = re.compile(r"[^\w\-]+", re.UNICODE)


def describe_error(exc: BaseException) -> str:
    """Return a readable Arabic message for any pipeline/engine/validation error."""
    if isinstance(exc, ValidationError):
        return "السكريبت فيه أخطاء:\n" + "\n".join(f"- {m}" for m in format_errors_ar(exc))
    if isinstance(exc, SafetyRejection):
        return "السكريبت اترفض من فلتر الأمان:\n" + "\n".join(
            f"- {m}" for m in exc.result.reasons("ar", include_warnings=False))
    if isinstance(exc, json.JSONDecodeError):
        return f"ملف الـ JSON مش سليم (سطر {exc.lineno}، عمود {exc.colno})"
    if isinstance(exc, (EngineError, ExportError)):
        return f"مشكلة في المحرك أو التصدير: {exc}"
    return f"حصل خطأ: {exc}"


# --------------------------------------------------------------------------- robot tab
def generate_message(name: str, gender: str, phase: str, mood: str = "", event_text: str = "",
                     *, config: Optional[dict[str, Any]] = None, library_path: Path | str = DEFAULT_PHRASES_PATH,
                     use_memory: bool = True) -> tuple[str, str, str]:
    """Pick a script. Returns (script_json, readable_text, status_message)."""
    try:
        patient = Patient(name=(name or "").strip() or "صديقي", gender=gender or "male")
        cfg = config if config is not None else load_config()
        memory = resolve_path(cfg.get("recent_memory_file", ".cache/recent_phrases.json")) if use_memory else None
        sel = select(patient.model_dump(mode="json"), phase, mood or None, event_text or None,
                     library=load_library(library_path), config=cfg, rng=random.Random(),
                     memory_path=memory, memory_size=cfg.get("recent_memory_size", 5),
                     alerts_log=resolve_path(cfg.get("alerts_log", "logs/alerts.log")))
        script = Script.model_validate(sel.script)
        text = "\n".join(s.text for m in personalize_script(script).messages for s in m.segments)
        status = ("⚠️ تم تفعيل التصعيد: الروبوت وقف السكريبت العادي وبلّغ الدكتور/الممرضة." if sel.escalated
                  else "تم توليد الرسالة. راجع النص قبل التشغيل.")
        return json.dumps(sel.script, ensure_ascii=False, indent=2), text, status
    except Exception as exc:  # shown to the user, never crashes the UI
        return "", "", describe_error(exc)


def render_audio(script_json: str, engine_name: str, voice: Optional[str] = None,
                 *, config: Optional[dict[str, Any]] = None, out_dir: Path | str | None = None,
                 fmt: str = "mp3", cache: Optional[AudioCache] = None) -> tuple[Optional[str], list[str], str]:
    """Run the full pipeline. Returns (audio_path, [audio, timestamps], status_message)."""
    try:
        data = json.loads(script_json)
        cfg = config if config is not None else load_config()
        engine = get_engine(engine_name or cfg.get("default_engine", "voicetut"), cfg)
        folder = Path(out_dir) if out_dir else resolve_path(UI_OUTPUT_DIR)
        folder.mkdir(parents=True, exist_ok=True)
        out = folder / f"message_{random.randrange(10**8):08d}.{fmt}"
        res = run_pipeline(data, engine, out, config=cfg, cache=cache, voice=voice or None)
        note = f"تم التوليد ({res.duration_ms / 1000:.1f} ثانية). الكاش: {res.cache_hits} موجود، {res.cache_misses} جديد."
        if res.warnings:
            note += "\nتنبيهات:\n" + "\n".join(f"- {w}" for w in res.warnings)
        return str(res.audio_path), [str(res.audio_path), str(res.timestamps_path)], note
    except Exception as exc:
        return None, [], describe_error(exc)


# --------------------------------------------------------------------------- editor tab
def validate_script_json(script_json: str) -> str:
    """Validate editor text: structure first, then safety. Returns an Arabic status."""
    try:
        script = Script.model_validate(json.loads(script_json))
        result = get_validator().validate_script(personalize_script(script))
        if not result.ok:
            return "السكريبت سليم من حيث الشكل لكن فلتر الأمان رفضه:\n" + "\n".join(
                f"- {m}" for m in result.reasons("ar", include_warnings=False))
        return "✅ السكريبت سليم وعدّى فلتر الأمان."
    except Exception as exc:
        return describe_error(exc)


def segment_table(script_json: str) -> list[list[Any]]:
    """Rows [index, category, part, text] for the editor's segment table."""
    try:
        data = json.loads(script_json)
        rows, i = [], 0
        for m in data.get("messages", []):
            for s in m.get("segments", []):
                rows.append([i, m.get("category", ""), s.get("part", ""), s.get("text", "")])
                i += 1
        return rows
    except Exception:
        return []


def render_segment(script_json: str, index: int, engine_name: str, voice: Optional[str] = None,
                   *, config: Optional[dict[str, Any]] = None, out_dir: Path | str | None = None,
                   cache: Optional[AudioCache] = None) -> tuple[Optional[str], str]:
    """Synthesize one segment alone (as a one-segment preview message)."""
    try:
        data = json.loads(script_json)
        flat = [(m, s) for m in data["messages"] for s in m["segments"]]
        message, seg = flat[int(index)]
        preview = {**{k: v for k, v in data.items() if k != "messages"},
                   "messages": [{"category": message["category"], "segments": [{**seg, "part": "core"}]}]}
        path, _files, note = render_audio(json.dumps(preview, ensure_ascii=False), engine_name, voice,
                                          config=config, out_dir=out_dir, cache=cache)
        return path, note
    except IndexError:
        return None, "رقم المقطع مش موجود."
    except Exception as exc:
        return None, describe_error(exc)


# --------------------------------------------------------------------------- voices tab
def voices_of(engine_name: str, config: Optional[dict[str, Any]] = None) -> tuple[list[str], str]:
    """List voices of an engine. Returns (voices, status)."""
    try:
        return get_engine(engine_name, config if config is not None else load_config()).list_voices(), ""
    except Exception as exc:
        return [], describe_error(exc)


def save_reference_voice(audio_path: Optional[str], name: str, transcript: str = "",
                         *, voices_dir: Path | str | None = None) -> str:
    """Copy an uploaded reference clip to voices/<name>.wav (+ optional transcript .txt)."""
    import soundfile as sf
    clean = _SAFE_NAME.sub("_", (name or "").strip()).strip("_")
    if not audio_path:
        return "ارفع ملف صوت مرجعي الأول."
    if not clean:
        return "اكتب اسم للصوت."
    folder = Path(voices_dir) if voices_dir else resolve_path(load_config().get("voicetut", {}).get("voices_dir", "voices"))
    try:
        data, sr = sf.read(audio_path, dtype="float32")
        folder.mkdir(parents=True, exist_ok=True)
        sf.write(str(folder / f"{clean}.wav"), data, sr)
        txt = folder / f"{clean}.txt"
        if transcript.strip():
            txt.write_text(transcript.strip(), encoding="utf-8")
        elif txt.exists():
            txt.unlink()
    except Exception as exc:
        return describe_error(exc)
    return f"تم حفظ الصوت المرجعي باسم «{clean}». هيظهر في قايمة الأصوات لمحرك voicetut."


# --------------------------------------------------------------------------- library tab
def _load_lib(path: Path | str) -> dict[str, dict[str, list[str]]]:
    return load_library(path)


def _save_lib(lib: dict[str, Any], path: Path | str) -> None:
    p = Path(path)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(lib, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(p)


def library_rows(category: str, part: str, path: Path | str = DEFAULT_PHRASES_PATH) -> list[list[Any]]:
    """Rows [index, phrase] for one category/part bucket."""
    return [[i, t] for i, t in enumerate(_load_lib(path).get(category, {}).get(part, []))]


def check_phrase(text: str, category: str, part: str) -> tuple[bool, str]:
    """Run the Safety Validator on a raw template. Returns (ok, Arabic message)."""
    text = (text or "").strip()
    if not text:
        return False, "الجملة فاضية."
    try:
        for gender in ("male", "female"):
            resolve_placeholders(text, "سارة", gender)
    except ValueError as exc:
        return False, f"صيغة الـ placeholders غلط: {exc}"
    result = get_validator().validate_template(text, category, part)
    if not result.ok:
        return False, "الجملة اترفضت:\n" + "\n".join(f"- {m}" for m in result.reasons("ar", include_warnings=False))
    warn = result.reasons("ar") if result.warnings else []
    return True, "الجملة سليمة." + ("\nتنبيهات:\n" + "\n".join(f"- {w}" for w in warn) if warn else "")


def _bucket(lib: dict, category: str, part: str) -> list[str]:
    if category not in {c.value for c in Category} or part not in {p.value for p in Part}:
        raise ValueError("فئة أو جزء غير معروف.")
    return lib.setdefault(category, {}).setdefault(part, [])


def library_add(category: str, part: str, text: str, path: Path | str = DEFAULT_PHRASES_PATH) -> tuple[bool, str]:
    """Add a phrase; it is written to disk only if the Safety Validator accepts it."""
    ok, msg = check_phrase(text, category, part)
    if not ok:
        return False, msg
    try:
        lib = _load_lib(path)
        bucket = _bucket(lib, category, part)
        if text.strip() in bucket:
            return False, "الجملة دي موجودة قبل كده."
        bucket.append(text.strip())
        _save_lib(lib, path)
    except ValueError as exc:
        return False, str(exc)
    return True, "تمت الإضافة. " + msg


def library_update(category: str, part: str, index: int, text: str,
                   path: Path | str = DEFAULT_PHRASES_PATH) -> tuple[bool, str]:
    """Edit a phrase in place (validated like a new phrase)."""
    ok, msg = check_phrase(text, category, part)
    if not ok:
        return False, msg
    try:
        lib = _load_lib(path)
        bucket = _bucket(lib, category, part)
        bucket[int(index)] = text.strip()
        _save_lib(lib, path)
    except IndexError:
        return False, "رقم الجملة مش موجود."
    except ValueError as exc:
        return False, str(exc)
    return True, "تم التعديل. " + msg


def library_delete(category: str, part: str, index: int, path: Path | str = DEFAULT_PHRASES_PATH,
                   min_remaining: int = 20) -> tuple[bool, str]:
    """Delete a phrase, but never drop a bucket below ``min_remaining`` (spec: 20+ per bucket)."""
    try:
        lib = _load_lib(path)
        bucket = _bucket(lib, category, part)
        if len(bucket) <= min_remaining:
            return False, f"مينفعش الحذف: لازم يفضل {min_remaining} جملة على الأقل في كل فئة وجزء."
        removed = bucket.pop(int(index))
        _save_lib(lib, path)
    except IndexError:
        return False, "رقم الجملة مش موجود."
    except ValueError as exc:
        return False, str(exc)
    return True, f"تم حذف: {removed}"


# --------------------------------------------------------------------------- gradio UI
RTL_CSS = ".gradio-container, .gradio-container * {direction: rtl; text-align: right;} " \
          "textarea, input, .cm-editor {direction: rtl;} .cm-editor {direction: ltr; text-align: left;}"
RTL_HEAD = "<script>document.documentElement.dir='rtl';document.documentElement.lang='ar';</script>"


def build_app():
    """Create the Gradio Blocks app (4 tabs). Returns (demo, launch_kwargs)."""
    import inspect

    import gradio as gr

    cfg = load_config()
    engines = [e for e in list_engines()]
    default_engine = cfg.get("default_engine", "voicetut")
    blocks_kw = {"title": "روبوت الرعاية بصوت مصري"}
    launch_kw: dict[str, Any] = {}
    target = blocks_kw if "css" in inspect.signature(gr.Blocks.__init__).parameters else launch_kw
    target.update(css=RTL_CSS, head=RTL_HEAD)

    with gr.Blocks(**blocks_kw) as demo:
        gr.Markdown("# روبوت مرافق المريض (صوت مصري)")
        engine_dd = gr.Dropdown(engines, value=default_engine, label="المحرك", render=False)
        voice_dd = gr.Dropdown([], label="الصوت (اختياري)", allow_custom_value=True, render=False)

        with gr.Tab("الروبوت"):
            with gr.Row():
                name = gr.Textbox(label="اسم المريض", value="")
                gender = gr.Radio([("ذكر", "male"), ("أنثى", "female")], value="female", label="النوع")
            with gr.Row():
                phase = gr.Dropdown([(v, k) for k, v in PHASE_LABELS.items()], value="before_session", label="المرحلة")
                mood = gr.Dropdown([(v, k) for k, v in MOOD_LABELS.items()], value="", label="المزاج")
            event = gr.Textbox(label="حدث (اختياري، مثلاً ألم شديد)")
            gen_btn = gr.Button("ولّد رسالة", variant="primary")
            text_out = gr.Textbox(label="النص للمراجعة", lines=5, interactive=False)
            script_out = gr.Code(label="السكريبت (JSON)", language="json")
            status = gr.Markdown()
            play_btn = gr.Button("شغّل الصوت")
            audio_out = gr.Audio(label="الصوت", type="filepath")
            files_out = gr.File(label="الملفات (الصوت + timestamps)", file_count="multiple")
            gen_btn.click(lambda n, g, p, m, e: generate_message(n, g, p, m, e),
                          [name, gender, phase, mood, event], [script_out, text_out, status])
            play_btn.click(lambda s, e, v: render_audio(s, e, v), [script_out, engine_dd, voice_dd],
                           [audio_out, files_out, status])

        with gr.Tab("المحرر"):
            editor = gr.Code(label="السكريبت (JSON)", language="json", lines=18)
            with gr.Row():
                load_btn = gr.Button("حمّل من تاب الروبوت")
                check_btn = gr.Button("تحقق")
                table_btn = gr.Button("اعرض المقاطع")
            ed_status = gr.Markdown()
            seg_table = gr.Dataframe(headers=["#", "الفئة", "الجزء", "النص"], interactive=False)
            with gr.Row():
                seg_idx = gr.Number(label="رقم المقطع", value=0, precision=0)
                seg_btn = gr.Button("شغّل المقطع")
            seg_audio = gr.Audio(label="المقطع", type="filepath")
            final_btn = gr.Button("ولّد الملف النهائي", variant="primary")
            final_files = gr.File(label="تحميل الملف النهائي", file_count="multiple")
            final_audio = gr.Audio(label="الصوت النهائي", type="filepath")
            load_btn.click(lambda s: s, script_out, editor)
            check_btn.click(validate_script_json, editor, ed_status)
            table_btn.click(segment_table, editor, seg_table)
            seg_btn.click(lambda s, i, e, v: render_segment(s, i, e, v), [editor, seg_idx, engine_dd, voice_dd],
                          [seg_audio, ed_status])
            final_btn.click(lambda s, e, v: render_audio(s, e, v), [editor, engine_dd, voice_dd],
                            [final_audio, final_files, ed_status])

        with gr.Tab("الأصوات"):
            engine_dd.render()
            refresh = gr.Button("حدّث قايمة الأصوات")
            voice_dd.render()
            v_status = gr.Markdown()
            gr.Markdown("### صوت مرجعي للاستنساخ (محرك voicetut)")
            ref_audio = gr.Audio(label="ملف صوت مرجعي", type="filepath")
            ref_name = gr.Textbox(label="اسم الصوت")
            ref_text = gr.Textbox(label="نص الكلام المسجّل (اختياري)")
            ref_btn = gr.Button("احفظ الصوت المرجعي")

            def refresh_voices(engine_name):
                voices, msg = voices_of(engine_name)
                return gr.update(choices=voices, value=voices[0] if voices else None), msg

            refresh.click(refresh_voices, engine_dd, [voice_dd, v_status])
            engine_dd.change(refresh_voices, engine_dd, [voice_dd, v_status])
            ref_btn.click(save_reference_voice, [ref_audio, ref_name, ref_text], v_status)
            demo.load(refresh_voices, engine_dd, [voice_dd, v_status])

        with gr.Tab("مكتبة الجمل"):
            with gr.Row():
                lib_cat = gr.Dropdown([(v, k) for k, v in CATEGORY_LABELS.items()], value="comfort", label="الفئة")
                lib_part = gr.Dropdown([(v, k) for k, v in PART_LABELS.items()], value="core", label="الجزء")
            lib_table = gr.Dataframe(headers=["#", "الجملة"], interactive=False, value=library_rows("comfort", "core"))
            lib_text = gr.Textbox(label="الجملة (استخدم {name} و {مذكر|مؤنث})")
            lib_idx = gr.Number(label="رقم الجملة (للتعديل أو الحذف)", value=0, precision=0)
            with gr.Row():
                add_btn = gr.Button("أضف", variant="primary")
                upd_btn = gr.Button("عدّل")
                del_btn = gr.Button("احذف")
                chk_btn = gr.Button("افحص بس")
            lib_status = gr.Markdown()

            def refresh_table(c, p):
                return library_rows(c, p)

            def act(fn):
                def run(c, p, i, t):
                    ok, msg = fn(c, p, i, t)
                    return library_rows(c, p), ("✅ " if ok else "❌ ") + msg
                return run

            add_btn.click(act(lambda c, p, i, t: library_add(c, p, t)), [lib_cat, lib_part, lib_idx, lib_text], [lib_table, lib_status])
            upd_btn.click(act(lambda c, p, i, t: library_update(c, p, i, t)), [lib_cat, lib_part, lib_idx, lib_text], [lib_table, lib_status])
            del_btn.click(act(lambda c, p, i, t: library_delete(c, p, i)), [lib_cat, lib_part, lib_idx, lib_text], [lib_table, lib_status])
            chk_btn.click(lambda c, p, t: ("✅ " if (r := check_phrase(t, c, p))[0] else "❌ ") + r[1], [lib_cat, lib_part, lib_text], lib_status)
            lib_cat.change(refresh_table, [lib_cat, lib_part], lib_table)
            lib_part.change(refresh_table, [lib_cat, lib_part], lib_table)
    return demo, launch_kw


def main() -> None:
    demo, launch_kw = build_app()
    demo.launch(server_name="127.0.0.1", server_port=7860, **launch_kw)


if __name__ == "__main__":
    main()
