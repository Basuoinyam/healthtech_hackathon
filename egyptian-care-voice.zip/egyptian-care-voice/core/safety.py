"""Content validator and escalation logic (spec section 3.7).

Stdlib only. Two responsibilities:

1. ``ContentValidator``: rejects text containing medical advice, medication or
   dosage talk, guaranteed-cure promises, toxic positivity (in comfort), and
   sentences that are too long or too short. Every rejection carries a reason.
2. Escalation: when the mood is ``pain`` or the patient's text signals an
   emergency, the normal script is stopped and a fixed calming line is used,
   an alert is appended to ``logs/alerts.log``, and an optional local callback
   or webhook is notified.

Rule data lives in ``data/blocked_phrases.json`` and can be edited without
touching this file.
"""
from __future__ import annotations

import json
import re
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable, Optional

from core.placeholders import resolve_placeholders

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RULES_PATH = PROJECT_ROOT / "data" / "blocked_phrases.json"
DEFAULT_ALERTS_LOG = PROJECT_ROOT / "logs" / "alerts.log"

# Fixed lines required by the spec. They are product content, so they stay Arabic.
ESCALATION_LINE = "أنا سامعك، وهبلّغ الدكتور أو الممرضة دلوقتي حالاً"
MEDICAL_QUESTION_REPLY = "ده سؤال مهم، خلّينا نسأل الدكتور"

SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"

# ---------------------------------------------------------------------------
# Arabic normalization
# ---------------------------------------------------------------------------
# Diacritics (tashkeel), superscript alef, tatweel, and invisible formatting
# characters that could be used to dodge the blocklist.
_MARKS_RE = re.compile("[\u064b-\u065f\u0670\u0640\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]")
_FOLD = str.maketrans({
    "أ": "ا", "إ": "ا", "آ": "ا", "ٱ": "ا",
    "ى": "ي", "ئ": "ي", "ؤ": "و", "ة": "ه",
})
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_PUNCT_RE = re.compile(r"[^\w\s]")
_SPACES_RE = re.compile(r"\s+")
_SENTENCE_SPLIT_RE = re.compile(r"[.!?؟!\n]+")
_WORD_RE = re.compile(r"\w+")
# Letters that Egyptian Arabic glues in front of a word (و ف ب ل ك).
_PREFIXES = "[وفبلك]{0,2}"


def strip_marks(text: str) -> str:
    """Remove diacritics, tatweel and invisible characters; keep punctuation."""
    return _MARKS_RE.sub("", text)


def normalize_ar(text: str) -> str:
    """Normalize Arabic text for matching.

    Removes diacritics, folds alef/yaa/taa-marbuta variants, converts Arabic
    digits to ASCII, lowercases, turns punctuation into spaces and collapses
    whitespace.
    """
    t = strip_marks(text).translate(_FOLD).translate(_DIGITS).lower()
    t = _PUNCT_RE.sub(" ", t)
    return _SPACES_RE.sub(" ", t).strip()


def count_words(text: str) -> int:
    """Count words in text, ignoring punctuation and diacritics."""
    return len(_WORD_RE.findall(strip_marks(text)))


def split_sentences(text: str) -> list[str]:
    """Split on . ! ? ؟ and newlines. An ellipsis is treated as a pause, not a break."""
    return [s.strip() for s in _SENTENCE_SPLIT_RE.split(text) if s.strip()]


def _phrase_regex(phrase: str) -> re.Pattern[str]:
    """Compile a normalized phrase into a whole-token regex."""
    words = [re.escape(w) for w in normalize_ar(phrase).split()]
    return re.compile(r"(?<!\w)" + _PREFIXES + r"\s+".join(words) + r"(?!\w)")


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------
@dataclass
class Violation:
    """One rejected piece of text, with the reason and where it was found."""

    rule: str
    severity: str
    matched: str
    reason_ar: str
    reason_en: str
    message_index: Optional[int] = None
    segment_index: Optional[int] = None
    part: Optional[str] = None
    gender: Optional[str] = None

    def describe(self, lang: str = "ar") -> str:
        reason = self.reason_ar if lang == "ar" else self.reason_en
        where = ""
        if self.message_index is not None:
            where = f"[messages.{self.message_index}.segments.{self.segment_index}] "
        what = f" ({self.matched})" if self.matched else ""
        return f"{where}{reason}{what}"


@dataclass
class SafetyResult:
    """Outcome of a validation. ``ok`` is False if any error-level violation exists."""

    violations: list[Violation] = field(default_factory=list)

    @property
    def errors(self) -> list[Violation]:
        return [v for v in self.violations if v.severity == SEVERITY_ERROR]

    @property
    def warnings(self) -> list[Violation]:
        return [v for v in self.violations if v.severity == SEVERITY_WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def reasons(self, lang: str = "ar", include_warnings: bool = True) -> list[str]:
        items = self.violations if include_warnings else self.errors
        return [v.describe(lang) for v in items]

    def extend(self, other: "SafetyResult") -> None:
        self.violations.extend(other.violations)


# ---------------------------------------------------------------------------
# Content validator
# ---------------------------------------------------------------------------
@dataclass
class _CompiledRule:
    name: str
    severity: str
    reason_ar: str
    reason_en: str
    categories: Optional[set[str]]
    patterns: list[re.Pattern[str]]


def _enum_value(x: Any) -> Any:
    return getattr(x, "value", x)


class ContentValidator:
    """Checks text against the rules in ``blocked_phrases.json``."""

    def __init__(self, rules: dict[str, Any]) -> None:
        self._rules = rules
        length = rules.get("length", {})
        self.max_words: int = int(length.get("max_words_per_sentence", 15))
        self.min_words: dict[str, int] = dict(length.get("min_words_per_segment", {}))
        self._compiled: list[_CompiledRule] = []
        for name, r in rules.get("rules", {}).items():
            patterns = [_phrase_regex(p) for p in r.get("phrases", [])]
            patterns += [re.compile(x) for x in r.get("regex", [])]
            cats = r.get("categories")
            self._compiled.append(_CompiledRule(
                name=name,
                severity=r.get("severity", SEVERITY_ERROR),
                reason_ar=r.get("reason_ar", name),
                reason_en=r.get("reason_en", name),
                categories=set(cats) if cats else None,
                patterns=patterns,
            ))
        mq = rules.get("medical_question", {})
        self._mq_terms = [_phrase_regex(t) for t in mq.get("terms", [])]
        self._mq_markers = [m for m in mq.get("markers", [])]
        self._mq_marker_res = [_phrase_regex(m) for m in self._mq_markers if normalize_ar(m)]
        self._emergency = [(t, _phrase_regex(t)) for t in rules.get("emergency_triggers", [])]

    @classmethod
    def from_file(cls, path: Path | str | None = None) -> "ContentValidator":
        p = Path(path) if path else DEFAULT_RULES_PATH
        return cls(json.loads(p.read_text(encoding="utf-8")))

    # -- text checks ------------------------------------------------------
    def validate_text(self, text: str, category: Any = None, part: Any = None) -> SafetyResult:
        """Validate one already-personalized text.

        ``category`` limits category-specific rules (toxic positivity applies
        to comfort only). ``part`` enables the per-part minimum length check.
        """
        cat = _enum_value(category)
        prt = _enum_value(part)
        result = SafetyResult()
        norm = normalize_ar(text)
        for rule in self._compiled:
            if rule.categories is not None and cat not in rule.categories:
                continue
            for pat in rule.patterns:
                m = pat.search(norm)
                if m:
                    result.violations.append(Violation(
                        rule=rule.name, severity=rule.severity, matched=m.group(0).strip(),
                        reason_ar=rule.reason_ar, reason_en=rule.reason_en, part=prt))
                    break  # one hit per rule is enough
        result.extend(self._check_length(text, prt))
        return result

    def _check_length(self, text: str, part: Optional[str]) -> SafetyResult:
        result = SafetyResult()
        for sentence in split_sentences(text):
            n = count_words(sentence)
            if n > self.max_words:
                result.violations.append(Violation(
                    rule="sentence_too_long", severity=SEVERITY_ERROR, matched=f"{n} كلمة",
                    reason_ar=f"الجملة طويلة ({n} كلمة)، الحد الأقصى {self.max_words} كلمة",
                    reason_en=f"Sentence has {n} words; maximum is {self.max_words}", part=part))
        if part in self.min_words:
            total = count_words(text)
            if total < self.min_words[part]:
                result.violations.append(Violation(
                    rule="segment_too_short", severity=SEVERITY_ERROR, matched=f"{total} كلمة",
                    reason_ar=f"المقطع قصير ({total} كلمة)، الحد الأدنى لجزء {part} هو {self.min_words[part]}",
                    reason_en=f"Segment has {total} words; minimum for {part} is {self.min_words[part]}",
                    part=part))
        return result

    def validate_template(self, text: str, category: Any = None, part: Any = None,
                          name: str = "سارة") -> SafetyResult:
        """Validate a raw template with {name} and {male|female} placeholders.

        Both gender forms are expanded and checked; identical violations are
        reported once. Use this for the phrase library and for new phrases.
        """
        result = SafetyResult()
        seen: set[tuple[str, str]] = set()
        for gender in ("male", "female"):
            expanded = resolve_placeholders(text, name, gender)
            for v in self.validate_text(expanded, category, part).violations:
                key = (v.rule, v.matched)
                if key in seen:
                    continue
                seen.add(key)
                v.gender = gender
                result.violations.append(v)
        return result

    def validate_script(self, script: Any) -> SafetyResult:
        """Validate every segment of a personalized script.

        Works with the pydantic ``Script`` model or any object/dict with the
        same shape. Run this after personalization (pipeline step 3).
        """
        result = SafetyResult()
        for mi, msg in enumerate(_get(script, "messages")):
            cat = _get(msg, "category")
            for si, seg in enumerate(_get(msg, "segments")):
                r = self.validate_text(_get(seg, "text"), cat, _get(seg, "part"))
                for v in r.violations:
                    v.message_index, v.segment_index = mi, si
                result.extend(r)
        return result

    # -- patient input checks ---------------------------------------------
    def is_medical_question(self, text: str) -> bool:
        """True if the patient's text looks like a medical question."""
        norm = normalize_ar(text)
        has_term = any(p.search(norm) for p in self._mq_terms)
        if not has_term:
            return False
        if "؟" in text or "?" in text:
            return True
        return any(p.search(norm) for p in self._mq_marker_res)

    def find_emergency(self, text: str) -> Optional[str]:
        """Return the first emergency trigger found in the patient's text, else None.

        Deliberately conservative: a negated phrase can still match, because a
        false alarm is safer than a missed one.
        """
        norm = normalize_ar(text)
        for trigger, pat in self._emergency:
            if pat.search(norm):
                return trigger
        return None


def _get(obj: Any, key: str) -> Any:
    return obj[key] if isinstance(obj, dict) else getattr(obj, key)


@lru_cache(maxsize=1)
def get_validator() -> ContentValidator:
    """Shared validator built from the default rules file."""
    return ContentValidator.from_file()


# ---------------------------------------------------------------------------
# Escalation
# ---------------------------------------------------------------------------
@dataclass
class EscalationResult:
    """What happened when an escalation was triggered."""

    reason: str                       # "mood_pain" or "emergency_text"
    trigger: str                      # the mood or the matched phrase
    line: str                         # fixed calming line to speak
    script: dict[str, Any]            # replaces the normal script
    logged: bool = False
    notified: bool = False
    errors: list[str] = field(default_factory=list)


def needs_escalation(mood: Any = None, event_text: Optional[str] = None,
                     validator: Optional[ContentValidator] = None) -> Optional[tuple[str, str]]:
    """Return (reason, trigger) if an escalation is needed, else None."""
    if _enum_value(mood) == "pain":
        return "mood_pain", "pain"
    if event_text:
        hit = (validator or get_validator()).find_emergency(event_text)
        if hit:
            return "emergency_text", hit
    return None


def build_escalation_script(patient: Any, phase: Any) -> dict[str, Any]:
    """Build a one-segment script (schema-shaped dict) with the fixed calming line."""
    pat: dict[str, Any] = {
        "name": _get(patient, "name"),
        "gender": _enum_value(_get(patient, "gender")),
    }
    voice = patient.get("preferred_voice") if isinstance(patient, dict) else getattr(patient, "preferred_voice", None)
    if voice:
        pat["preferred_voice"] = voice
    return {
        "patient": pat,
        "phase": _enum_value(phase),
        "output_format": "mp3",
        "messages": [{
            "category": "comfort",
            "segments": [{"part": "core", "text": ESCALATION_LINE, "speed": 0.88, "pause_after_ms": 800}],
        }],
    }


def log_alert(entry: dict[str, Any], alerts_log: Path | str = DEFAULT_ALERTS_LOG) -> None:
    """Append one JSON line to the alerts log, creating the folder if needed."""
    p = Path(alerts_log)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _post_webhook(url: str, payload: dict[str, Any], timeout: float) -> None:
    if not url.lower().startswith(("http://", "https://")):
        raise ValueError(f"Webhook URL must start with http:// or https://: {url!r}")
    req = urllib.request.Request(
        url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout):  # noqa: S310 (scheme checked above)
        pass


def escalate(patient: Any, phase: Any, reason: str, trigger: str, *,
             mood: Any = None,
             alerts_log: Path | str = DEFAULT_ALERTS_LOG,
             callback: Optional[Callable[[dict[str, Any]], None]] = None,
             webhook_url: Optional[str] = None,
             webhook_timeout: float = 3.0) -> EscalationResult:
    """Stop the normal script and raise an alert.

    Logging, the callback and the webhook are independent: a failure in one is
    recorded in ``errors`` and never prevents the others or the calming line.
    """
    alert = {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "level": "ALERT",
        "reason": reason,
        "trigger": trigger,
        "mood": _enum_value(mood),
        "phase": _enum_value(phase),
        "patient": _get(patient, "name"),
    }
    res = EscalationResult(reason=reason, trigger=trigger, line=ESCALATION_LINE,
                           script=build_escalation_script(patient, phase))
    try:
        log_alert(alert, alerts_log)
        res.logged = True
    except Exception as exc:  # the line must still be spoken
        res.errors.append(f"log failed: {exc}")
    if callback is not None:
        try:
            callback(alert)
            res.notified = True
        except Exception as exc:
            res.errors.append(f"callback failed: {exc}")
    if webhook_url:
        try:
            _post_webhook(webhook_url, alert, webhook_timeout)
            res.notified = True
        except Exception as exc:
            res.errors.append(f"webhook failed: {exc}")
    return res


def check_and_escalate(patient: Any, phase: Any, mood: Any = None,
                       event_text: Optional[str] = None, **kwargs: Any) -> Optional[EscalationResult]:
    """Main entry point for the selector: escalate if mood or text requires it.

    Returns None when everything is normal. Extra keyword arguments are passed
    to :func:`escalate` (alerts_log, callback, webhook_url, webhook_timeout).
    """
    hit = needs_escalation(mood, event_text)
    if hit is None:
        return None
    reason, trigger = hit
    return escalate(patient, phase, reason, trigger, mood=mood, **kwargs)
