"""Stdlib-only placeholder resolution ({name} and {male|female}).

Kept free of pydantic so that safety checks and tests can use it without
importing the schema module.
"""
from __future__ import annotations

import re

GENDER_RE = re.compile(r"\{([^{}|]+)\|([^{}|]+)\}")
_VALID_GENDERS = ("male", "female")


def resolve_placeholders(text: str, name: str, gender: str) -> str:
    """Return text with {name} and {male|female} forms resolved.

    ``gender`` must be "male" or "female" (a str-based Enum also works).
    Raises ValueError for an unknown gender or any unresolved placeholder.
    """
    g = getattr(gender, "value", gender)
    if g not in _VALID_GENDERS:
        raise ValueError(f"Unknown gender: {gender!r}")
    text = text.replace("{name}", name)
    pick = 1 if g == "male" else 2
    text = GENDER_RE.sub(lambda m: m.group(pick).strip(), text)
    if "{" in text or "}" in text:
        raise ValueError(f"Unresolved placeholder in text: {text!r}")
    return text
