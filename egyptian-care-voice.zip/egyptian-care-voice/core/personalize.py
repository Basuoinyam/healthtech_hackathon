"""Replace {name} and {male|female} placeholders based on patient data."""
from __future__ import annotations

from core.placeholders import resolve_placeholders
from core.schema import Gender, Script


def personalize_text(text: str, name: str, gender: Gender | str) -> str:
    """Return text with {name} and {male|female} forms resolved.

    Raises ValueError if any unresolved placeholder remains.
    """
    g = Gender(gender)
    return resolve_placeholders(text, name, g.value)


def personalize_script(script: Script) -> Script:
    """Return a deep copy of the script with all segments personalized."""
    new = script.model_copy(deep=True)
    for msg in new.messages:
        for seg in msg.segments:
            seg.text = personalize_text(seg.text, new.patient.name, new.patient.gender)
    return new
