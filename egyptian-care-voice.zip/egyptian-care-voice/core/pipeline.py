"""End-to-end pipeline (spec section 4): validate, personalize, safety check,
preprocess, synthesize (with cache), post-process, assemble, export.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import numpy as np
from pydub import AudioSegment

from core import audio as au
from core.cache import AudioCache
from core.personalize import personalize_script
from core.preprocess import load_pronunciation, prepare_text
from core.safety import ContentValidator, SafetyResult, get_validator
from core.schema import Script
from core.selector import load_config, resolve_path

DEFAULT_AUDIO = {
    "target_lufs": -23.0, "fade_in_ms": 150, "fade_out_ms": 30, "chunk_pause_ms": 150,
    "default_pause_ms": 400, "pause_between_messages_ms": 1200, "mp3_bitrate": "128k",
}


class SafetyRejection(Exception):
    """Raised when the personalized script fails the Content Validator."""

    def __init__(self, result: SafetyResult) -> None:
        self.result = result
        super().__init__("; ".join(result.reasons("en", include_warnings=False)))


@dataclass
class PipelineResult:
    audio_path: Path
    timestamps_path: Path
    timestamps: list[dict[str, Any]]
    duration_ms: int
    cache_hits: int = 0
    cache_misses: int = 0
    warnings: list[str] = field(default_factory=list)


def timestamps_path_for(audio_path: Path) -> Path:
    """Return ``<audio stem>.timestamps.json`` next to the audio file."""
    return audio_path.with_name(audio_path.stem + ".timestamps.json")


def _resolve_voice(engine: Any, segment_voice: Optional[str], patient_voice: Optional[str],
                   override: Optional[str], warnings: list[str]) -> Optional[str]:
    available = engine.list_voices()
    for wanted in (override, segment_voice, patient_voice):
        if not wanted:
            continue
        if wanted in available:
            return wanted
        msg = f"Voice {wanted!r} is not available in engine {engine.name!r}; using the default voice."
        if msg not in warnings:
            warnings.append(msg)
    return available[0] if available else None


def run_pipeline(script: Script | dict[str, Any], engine: Any, out_path: Path | str, *,
                 config: Optional[dict[str, Any]] = None,
                 cache: Optional[AudioCache] = None,
                 pronunciation: Optional[dict[str, str]] = None,
                 validator: Optional[ContentValidator] = None,
                 voice: Optional[str] = None) -> PipelineResult:
    """Turn a script into an audio file plus ``timestamps.json``.

    Raises ``pydantic.ValidationError`` for a bad script, ``SafetyRejection`` for
    forbidden content, and engine/export errors from the lower layers.
    """
    cfg = config if config is not None else load_config()
    acfg = {**DEFAULT_AUDIO, **(cfg.get("audio") or {})}
    presets = cfg.get("category_presets") or {}
    max_words = int((cfg.get("preprocess") or {}).get("max_chunk_words", 15))
    if pronunciation is None:
        pron_file = (cfg.get("preprocess") or {}).get("pronunciation_file")
        pronunciation = load_pronunciation(resolve_path(pron_file) if pron_file else None)
    if cache is None:
        cache = AudioCache(resolve_path(cfg.get("cache_dir", ".cache")) / "audio")

    # 1-3. parse, personalize, safety check
    parsed = script if isinstance(script, Script) else Script.model_validate(script)
    personalized = personalize_script(parsed)
    safety = (validator or get_validator()).validate_script(personalized)
    if not safety.ok:
        raise SafetyRejection(safety)
    warnings = safety.reasons("ar") if safety.warnings else []

    out_path = Path(out_path)
    fmt = out_path.suffix.lstrip(".").lower()
    if fmt not in {"mp3", "wav"}:
        fmt = personalized.output_format
        out_path = out_path.with_name(out_path.name + "." + fmt)

    result = AudioSegment.empty()
    timestamps: list[dict[str, Any]] = []
    sample_rate: Optional[int] = None
    hits0, misses0 = cache.hits, cache.misses
    n_messages = len(personalized.messages)

    for mi, message in enumerate(personalized.messages):
        preset = presets.get(message.category.value, {})
        for si, seg in enumerate(message.segments):
            voice_id = _resolve_voice(engine, seg.voice, personalized.patient.preferred_voice,
                                      voice, warnings)
            speed = seg.speed if seg.speed is not None else float(preset.get("speed", 1.0))
            emotion = seg.emotion if seg.emotion is not None else preset.get("emotion")
            params: dict[str, Any] = {}
            stretch = 1.0
            if engine.supports("speed"):
                params["speed"] = speed
            else:
                stretch = speed
            if emotion and engine.supports("emotion"):
                params["emotion"] = emotion

            # 4-5. preprocess and synthesize chunk by chunk
            pieces: list[np.ndarray] = []
            for chunk in prepare_text(seg.text, pronunciation, max_words):
                key = AudioCache.make_key(chunk, voice_id, getattr(engine, "model_id", engine.name), params)
                cached = cache.get(key)
                if cached is None:
                    raw, sr = engine.synthesize(chunk, voice_id, **params)
                    cache.put(key, au.to_mono_float32(raw), sr)
                else:
                    raw, sr = cached
                if sample_rate is None:
                    sample_rate = sr
                a = au.to_mono_float32(raw)
                if sr != sample_rate:  # engines should not mix rates, but be safe
                    a = au.to_mono_float32(np.frombuffer(
                        au.to_segment(a, sr).set_frame_rate(sample_rate).raw_data, np.int16) / 32768.0)
                pieces.append(au.time_stretch(a, stretch) if stretch != 1.0 else a)
                pieces.append(au.silence_ms(acfg["chunk_pause_ms"], sample_rate))
            if not pieces:
                continue
            seg_audio = np.concatenate(pieces[:-1])  # drop trailing chunk pause

            # 6. post-process: same loudness for every segment, soft edges
            seg_audio = au.normalize_loudness(seg_audio, sample_rate, acfg["target_lufs"])
            seg_audio = au.fade_in(seg_audio, sample_rate, acfg["fade_in_ms"] if si == 0 else 10)
            seg_audio = au.fade_out(seg_audio, sample_rate, acfg["fade_out_ms"])

            # 7. assemble
            piece = au.to_segment(seg_audio, sample_rate)
            start = len(result)
            result += piece
            timestamps.append({
                "message_index": mi, "segment_index": si, "category": message.category.value,
                "part": seg.part.value, "text": seg.text, "voice": voice_id,
                "start_ms": start, "end_ms": len(result),
            })
            is_last_segment = si == len(message.segments) - 1
            is_last_message = mi == n_messages - 1
            if not (is_last_segment and is_last_message):
                pause = seg.pause_after_ms if seg.pause_after_ms is not None else int(
                    preset.get("pause_after_ms", acfg["default_pause_ms"]))
                if is_last_segment:
                    pause = max(pause, int(acfg["pause_between_messages_ms"]))
                result += AudioSegment.silent(duration=pause, frame_rate=sample_rate)

    if not timestamps:
        raise ValueError("Script produced no audio")

    # 8. export
    au.export_audio(result, out_path, fmt, str(acfg["mp3_bitrate"]))
    ts_path = timestamps_path_for(out_path)
    ts_path.write_text(json.dumps({
        "audio": out_path.name, "engine": engine.name, "duration_ms": len(result),
        "segments": timestamps,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return PipelineResult(audio_path=out_path, timestamps_path=ts_path, timestamps=timestamps,
                          duration_ms=len(result), cache_hits=cache.hits - hits0,
                          cache_misses=cache.misses - misses0, warnings=warnings)
