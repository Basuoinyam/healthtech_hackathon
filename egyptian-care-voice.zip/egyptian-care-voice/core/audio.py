"""Audio post-processing and assembly (spec section 4, steps 6 and 7)."""
from __future__ import annotations

import os
import shutil
from pathlib import Path

import numpy as np
import pyloudnorm as pyln
from pydub import AudioSegment

TARGET_PEAK = 0.97
_PROJECT_ROOT = Path(__file__).resolve().parent.parent


def configure_ffmpeg() -> str | None:
    """Pick the ffmpeg binary pydub should use and return its path (or None).

    A system ``ffmpeg`` on PATH always wins. On Windows only, a ``ffmpeg.exe`` placed
    in the project root is used as a fallback. A Windows .exe is never used elsewhere.
    """
    system = shutil.which("ffmpeg")
    if system:
        AudioSegment.converter = system
        return system
    local = _PROJECT_ROOT / "ffmpeg.exe"
    if os.name == "nt" and local.is_file():
        AudioSegment.converter = str(local)
        return str(local)
    try:
        import imageio_ffmpeg
        bundled = imageio_ffmpeg.get_ffmpeg_exe()
        if bundled and Path(bundled).is_file():
            AudioSegment.converter = bundled
            return bundled
    except (ImportError, RuntimeError, OSError):
        pass
    return None


configure_ffmpeg()


def to_mono_float32(audio: np.ndarray) -> np.ndarray:
    """Return a 1-D float32 array (mono). Multi-channel input is averaged."""
    a = np.asarray(audio, dtype=np.float32)
    if a.ndim == 2:
        a = a.mean(axis=1 if a.shape[1] <= 8 else 0)
    return a.reshape(-1)


def fade_in(audio: np.ndarray, sr: int, ms: float) -> np.ndarray:
    """Apply a half-cosine fade-in over the first ``ms`` milliseconds."""
    n = min(len(audio), int(sr * ms / 1000))
    if n <= 0:
        return audio
    out = audio.copy()
    out[:n] *= (0.5 - 0.5 * np.cos(np.pi * np.arange(n) / n)).astype(np.float32)
    return out


def fade_out(audio: np.ndarray, sr: int, ms: float) -> np.ndarray:
    """Apply a half-cosine fade-out over the last ``ms`` milliseconds."""
    n = min(len(audio), int(sr * ms / 1000))
    if n <= 0:
        return audio
    out = audio.copy()
    out[-n:] *= (0.5 + 0.5 * np.cos(np.pi * np.arange(n) / n)).astype(np.float32)
    return out


def normalize_loudness(audio: np.ndarray, sr: int, target_lufs: float = -23.0) -> np.ndarray:
    """Scale audio to ``target_lufs`` (integrated loudness), then cap the peak.

    Every segment gets the same loudness, so there are no sudden jumps between
    segments. Clips shorter than 0.4 s are tiled for measurement only.
    """
    if audio.size == 0:
        return audio
    measure = audio
    min_len = int(sr * 0.4) + 1
    if measure.size < min_len:
        measure = np.tile(measure, int(np.ceil(min_len / measure.size)))
    loudness = pyln.Meter(sr).integrated_loudness(measure.astype(np.float64))
    if not np.isfinite(loudness):  # silence
        return audio
    gain = 10 ** (np.clip(target_lufs - loudness, -30.0, 30.0) / 20.0)
    out = audio * np.float32(gain)
    peak = float(np.max(np.abs(out)))
    if peak > TARGET_PEAK:
        out = out * np.float32(TARGET_PEAK / peak)
    return out.astype(np.float32, copy=False)


def time_stretch(audio: np.ndarray, rate: float, frame: int = 1024) -> np.ndarray:
    """Change speed without changing pitch (WSOLA). rate > 1 is faster.

    Simple pure-numpy implementation, intended for modest changes (0.5 to 1.5)
    when an engine has no native speed control.
    """
    if rate <= 0:
        raise ValueError("rate must be > 0")
    if abs(rate - 1.0) < 0.01 or len(audio) < frame * 2:
        return audio
    hop = frame // 2
    tol = frame // 4
    window = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(frame) / frame)).astype(np.float32)
    padded = np.concatenate([np.zeros(tol, np.float32), audio, np.zeros(frame * 2 + tol, np.float32)])
    n_frames = int(len(audio) / rate / hop) + 1
    out = np.zeros(n_frames * hop + frame, np.float32)
    selected = tol  # index in padded of the previously selected frame
    for k in range(n_frames):
        if k == 0:
            start = tol
        else:
            target = padded[selected + hop: selected + hop + frame]
            nominal = tol + int(k * hop * rate)
            lo, hi = max(0, nominal - tol), min(len(padded) - frame, nominal + tol)
            if hi <= lo or len(target) < frame:
                start = min(max(lo, 0), len(padded) - frame)
            else:
                cands = np.lib.stride_tricks.sliding_window_view(padded[lo: hi + frame], frame)
                start = lo + int(np.argmax(cands @ target))
        out[k * hop: k * hop + frame] += padded[start: start + frame] * window
        selected = start
    return out[: int(len(audio) / rate)]


def to_segment(audio: np.ndarray, sr: int) -> AudioSegment:
    """Convert mono float audio to a pydub AudioSegment (16-bit)."""
    pcm = (np.clip(audio, -1.0, 1.0) * 32767.0).astype(np.int16)
    return AudioSegment(data=pcm.tobytes(), sample_width=2, frame_rate=sr, channels=1)


def silence_ms(ms: int, sr: int) -> np.ndarray:
    """Return ``ms`` milliseconds of silence as float32."""
    return np.zeros(int(sr * max(0, ms) / 1000), np.float32)


class ExportError(RuntimeError):
    """Raised when the final file cannot be written (usually ffmpeg is missing)."""


def export_audio(segment: AudioSegment, path: Path, fmt: str, bitrate: str = "128k") -> Path:
    """Write the assembled audio as mp3 or wav via pydub/ffmpeg."""
    fmt = fmt.lower()
    if fmt not in {"mp3", "wav"}:
        raise ExportError(f"Unsupported output format {fmt!r}; use mp3 or wav")
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        if fmt == "wav":
            segment.export(str(path), format="wav")
        else:
            segment.export(str(path), format="mp3", bitrate=bitrate)
    except FileNotFoundError as exc:
        raise ExportError("ffmpeg was not found. Install it (Linux: 'sudo apt install ffmpeg'; Windows: put "
                          "ffmpeg.exe in the project root or on PATH), or use --out with a .wav file.") from exc
    except Exception as exc:  # pydub raises CouldntEncodeError and friends
        raise ExportError(f"Could not write {path}: {exc}") from exc
    return path
