"""Pydantic models for the input script plus Arabic error formatting."""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator


class Category(str, Enum):
    encouragement = "encouragement"
    positivity = "positivity"
    comfort = "comfort"


class Part(str, Enum):
    opening = "opening"
    acknowledgment = "acknowledgment"
    core = "core"
    closing = "closing"


PART_ORDER = [Part.opening, Part.acknowledgment, Part.core, Part.closing]


class Phase(str, Enum):
    morning_checkin = "morning_checkin"
    before_session = "before_session"
    during_session = "during_session"
    after_session = "after_session"
    bad_day = "bad_day"
    milestone = "milestone"
    night = "night"


class Mood(str, Enum):
    good = "good"
    tired = "tired"
    anxious = "anxious"
    sad = "sad"
    pain = "pain"


class Gender(str, Enum):
    male = "male"
    female = "female"


class Patient(BaseModel):
    name: str = Field(min_length=1)
    gender: Gender
    preferred_voice: Optional[str] = None

    @field_validator("name")
    @classmethod
    def _strip_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("empty name")
        return v


class Segment(BaseModel):
    part: Part
    text: str = Field(min_length=1)
    speed: Optional[float] = Field(default=None, ge=0.5, le=1.5)
    emotion: Optional[str] = None
    pause_after_ms: Optional[int] = Field(default=None, ge=0, le=5000)
    voice: Optional[str] = None

    @field_validator("text")
    @classmethod
    def _strip_text(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("empty text")
        return v


class Message(BaseModel):
    category: Category
    segments: list[Segment] = Field(min_length=1)

    @model_validator(mode="after")
    def _check_structure(self) -> "Message":
        idx = [PART_ORDER.index(s.part) for s in self.segments]
        if idx != sorted(idx):
            raise ValueError("segments_order")
        if len(set(idx)) != len(idx):
            raise ValueError("segments_duplicate")
        if Part.core not in [s.part for s in self.segments]:
            raise ValueError("segments_no_core")
        return self


class Script(BaseModel):
    patient: Patient
    phase: Phase
    output_format: str = "mp3"
    messages: list[Message] = Field(min_length=1)

    @field_validator("output_format")
    @classmethod
    def _check_format(cls, v: str) -> str:
        v = v.lower()
        if v not in {"mp3", "wav"}:
            raise ValueError("bad_format")
        return v


# ---- Arabic error formatting -------------------------------------------------
_AR_TYPES = {
    "missing": "الحقل ده ناقص ومطلوب",
    "string_too_short": "النص قصير جداً أو فاضي",
    "too_short": "القايمة فاضية ولازم يكون فيها عنصر واحد على الأقل",
    "enum": "القيمة دي مش من القيم المسموحة",
    "greater_than_equal": "القيمة أقل من الحد الأدنى المسموح",
    "less_than_equal": "القيمة أكتر من الحد الأقصى المسموح",
    "string_type": "لازم القيمة تكون نص",
    "int_type": "لازم القيمة تكون رقم صحيح",
    "float_type": "لازم القيمة تكون رقم",
    "list_type": "لازم القيمة تكون قايمة",
    "model_type": "الشكل غلط، المفروض يكون كائن JSON",
    "json_invalid": "ملف الـ JSON مش سليم",
}
_AR_CUSTOM = {
    "segments_order": "ترتيب المقاطع غلط، لازم يكون: opening ثم acknowledgment ثم core ثم closing",
    "segments_duplicate": "فيه جزء مكرر في نفس الرسالة، كل جزء يتكتب مرة واحدة بس",
    "segments_no_core": "الرسالة لازم يكون فيها مقطع core (الرسالة الأساسية)",
    "bad_format": "output_format لازم يكون mp3 أو wav",
    "empty name": "اسم المريض فاضي",
    "empty text": "نص المقطع فاضي",
}


def format_errors_ar(exc: ValidationError) -> list[str]:
    """Convert a pydantic ValidationError to readable Arabic messages."""
    out: list[str] = []
    for err in exc.errors():
        loc = ".".join(str(p) for p in err["loc"]) or "(root)"
        msg = err.get("msg", "")
        ar = None
        if err["type"] == "value_error":
            for key, text in _AR_CUSTOM.items():
                if key in msg:
                    ar = text
                    break
        ar = ar or _AR_TYPES.get(err["type"], f"قيمة غير صالحة ({msg})")
        out.append(f"[{loc}] {ar}")
    return out
