"""Pick a script for a (phase, mood) pair from the phrase library.

Order of operations (spec 3.7 / 3.8):
1. ``check_and_escalate`` runs FIRST. If the mood is ``pain`` or the patient's
   text signals an emergency, the normal script is dropped and the escalation
   script is returned.
2. Otherwise the plan for the phase/mood comes from ``data/selection_rules.json``.
3. Phrases are drawn at random from ``data/phrases.json`` while avoiding the
   last N phrases used (memory kept in a small JSON file).

The returned script keeps ``{name}`` / ``{male|female}`` placeholders; they are
resolved later by ``core.personalize`` (pipeline step 2).
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

import yaml

from core.safety import EscalationResult, check_and_escalate
from core.schema import Mood, Phase

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PHRASES_PATH = PROJECT_ROOT / "data" / "phrases.json"
DEFAULT_RULES_PATH = PROJECT_ROOT / "data" / "selection_rules.json"
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config.yaml"


@dataclass
class Selection:
    """Result of :func:`select`."""

    script: dict[str, Any]
    escalation: Optional[EscalationResult] = None
    phrases: Optional[list[str]] = None  # raw templates used (None when escalated)

    @property
    def escalated(self) -> bool:
        return self.escalation is not None


# ---------------------------------------------------------------------------
# Loading helpers
# ---------------------------------------------------------------------------
def load_json(path: Path | str) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def load_library(path: Path | str = DEFAULT_PHRASES_PATH) -> dict[str, dict[str, list[str]]]:
    """Load the phrase library: ``{category: {part: [templates]}}``."""
    return load_json(path)


def load_rules(path: Path | str = DEFAULT_RULES_PATH) -> dict[str, Any]:
    return load_json(path)


def load_config(path: Path | str = DEFAULT_CONFIG_PATH) -> dict[str, Any]:
    return yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}


def resolve_path(p: Path | str) -> Path:
    """Resolve a config path relative to the project root."""
    p = Path(p)
    return p if p.is_absolute() else PROJECT_ROOT / p


# ---------------------------------------------------------------------------
# Memory of recently used phrases
# ---------------------------------------------------------------------------
def load_recent(path: Optional[Path | str]) -> list[str]:
    """Read the recent-phrases memory. A missing or corrupt file means empty."""
    if path is None:
        return []
    p = Path(path)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        recent = data.get("recent", []) if isinstance(data, dict) else []
        return [x for x in recent if isinstance(x, str)]
    except (OSError, ValueError):
        return []


def save_recent(path: Optional[Path | str], recent: list[str]) -> None:
    if path is None:
        return
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps({"recent": recent}, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def _pick(bucket: list[str], avoid: list[str], rng: random.Random) -> str:
    """Pick a phrase not in ``avoid``; if impossible, the least recently used one."""
    fresh = [t for t in bucket if t not in avoid]
    if fresh:
        return rng.choice(fresh)
    # Tiny bucket: reuse the phrase whose LAST use is the oldest (never the one just said).
    def last_use(t: str) -> int:
        return max((i for i, a in enumerate(avoid) if a == t), default=-1)

    return min(bucket, key=last_use)


# ---------------------------------------------------------------------------
# Selection
# ---------------------------------------------------------------------------
def _patient_dict(patient: Any) -> dict[str, Any]:
    if isinstance(patient, dict):
        d = dict(patient)
    else:
        d = {k: getattr(patient, k) for k in ("name", "gender", "preferred_voice") if hasattr(patient, k)}
    d["gender"] = getattr(d.get("gender"), "value", d.get("gender"))
    return {k: v for k, v in d.items() if v is not None}


def _plan_for(rules: dict[str, Any], phase: str, mood: Optional[str]) -> list[dict[str, Any]]:
    """tired/anxious/sad override the phase; good uses the phase's 'good' plan; else the default."""
    override = rules.get("moods", {}).get(mood) if mood else None
    if override:
        return override
    entry = rules["phases"][phase]
    if mood == "good" and "good" in entry:
        return entry["good"]
    return entry["default"]


def select(patient: Any, phase: Any, mood: Any = None, event_text: Optional[str] = None, *,
           library: Optional[dict[str, dict[str, list[str]]]] = None,
           rules: Optional[dict[str, Any]] = None,
           config: Optional[dict[str, Any]] = None,
           rng: Optional[random.Random] = None,
           memory_path: Optional[Path | str] = None,
           memory_size: Optional[int] = None,
           alerts_log: Optional[Path | str] = None,
           callback: Optional[Callable[[dict[str, Any]], None]] = None,
           webhook_url: Optional[str] = None) -> Selection:
    """Build a script for ``phase``/``mood``.

    Raises ValueError for an unknown phase or mood. ``memory_path=None`` means
    no persistent memory (phrases are still never repeated inside one script).
    """
    phase_v = Phase(getattr(phase, "value", phase)).value
    mood_v = Mood(getattr(mood, "value", mood)).value if mood else None
    pat = _patient_dict(patient)

    # 1) Safety first: nothing else may run before this.
    esc_kwargs: dict[str, Any] = {"callback": callback, "webhook_url": webhook_url}
    if alerts_log is not None:
        esc_kwargs["alerts_log"] = alerts_log
    esc = check_and_escalate(pat, phase_v, mood=mood_v, event_text=event_text, **esc_kwargs)
    if esc is not None:
        return Selection(script=esc.script, escalation=esc)

    # 2) Plan and phrase pick.
    library = library if library is not None else load_library()
    rules = rules if rules is not None else load_rules()
    config = config if config is not None else load_config()
    rng = rng or random.Random()
    size = memory_size if memory_size is not None else int(config.get("recent_memory_size", 5))
    presets = config.get("category_presets", {})

    recent = load_recent(memory_path)
    used: list[str] = []
    messages: list[dict[str, Any]] = []
    for spec in _plan_for(rules, phase_v, mood_v):
        cat = spec["category"]
        preset = presets.get(cat, {})
        segments = []
        for part in spec["parts"]:
            avoid = (recent + used)[-size:] if size > 0 else used
            text = _pick(library[cat][part], avoid, rng)
            used.append(text)
            seg: dict[str, Any] = {"part": part, "text": text}
            if "speed" in preset:
                seg["speed"] = preset["speed"]
            if "emotion" in preset:
                seg["emotion"] = preset["emotion"]
            if "pause_after_ms" in preset:
                seg["pause_after_ms"] = preset["pause_after_ms"]
            segments.append(seg)
        messages.append({"category": cat, "segments": segments})
    if messages:
        messages[-1]["segments"][-1]["pause_after_ms"] = 0  # no dead air at the end

    save_recent(memory_path, (recent + used)[-size:] if size > 0 else [])
    script = {"patient": pat, "phase": phase_v, "output_format": config.get("output_format", "mp3"),
              "messages": messages}
    return Selection(script=script, phrases=used)


def select_script(*args: Any, **kwargs: Any) -> dict[str, Any]:
    """Like :func:`select` but returns only the script dict."""
    return select(*args, **kwargs).script
