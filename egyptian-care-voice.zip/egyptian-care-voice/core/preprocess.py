"""Text preprocessing before synthesis (spec section 4, step 4).

Cleans whitespace and symbols, converts digits to Egyptian Arabic words,
applies the pronunciation dictionary and splits long text into short chunks.
Stdlib only.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Mapping, Optional

_INVISIBLE_RE = re.compile("[\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff\u0640]")
_SYMBOLS_RE = re.compile(r"[*_#~^|<>\[\]{}\\/@=+]")
_SPACE_BEFORE_PUNCT_RE = re.compile(r"\s+([.,!?؟،؛:])")
_REPEAT_PUNCT_RE = re.compile(r"([!?؟،,])\1+")
_SPACES_RE = re.compile(r"\s+")
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
_NUMBER_RE = re.compile(r"\d+")
_CHUNK_RE = re.compile(r"[^.!?؟\n]+[.!?؟]*")

_ONES = ["صفر", "واحد", "اتنين", "تلاتة", "أربعة", "خمسة", "ستة", "سبعة", "تمانية", "تسعة",
         "عشرة", "حداشر", "اتناشر", "تلاتاشر", "أربعتاشر", "خمستاشر", "ستاشر", "سبعتاشر",
         "تمنتاشر", "تسعتاشر"]
_TENS = {2: "عشرين", 3: "تلاتين", 4: "أربعين", 5: "خمسين", 6: "ستين", 7: "سبعين",
         8: "تمانين", 9: "تسعين"}
_HUNDREDS = {1: "مية", 2: "ميتين", 3: "تلتمية", 4: "ربعمية", 5: "خمسمية", 6: "ستمية",
             7: "سبعمية", 8: "تمنمية", 9: "تسعمية"}
_THOUSANDS = {1: "ألف", 2: "ألفين", 3: "تلات تلاف", 4: "أربع تلاف", 5: "خمس تلاف",
              6: "ست تلاف", 7: "سبع تلاف", 8: "تمن تلاف", 9: "تسع تلاف", 10: "عشر تلاف"}
MAX_SPOKEN_NUMBER = 999_999


def clean_text(text: str) -> str:
    """Remove invisible characters and stray symbols, and tidy spaces and punctuation."""
    t = _INVISIBLE_RE.sub("", text)
    t = _SYMBOLS_RE.sub(" ", t)
    t = _REPEAT_PUNCT_RE.sub(r"\1", t)
    t = _SPACES_RE.sub(" ", t).strip()
    return _SPACE_BEFORE_PUNCT_RE.sub(r"\1", t)


def number_to_words(n: int) -> str:
    """Spell an integer in 0..999999 in Egyptian Arabic. Larger numbers raise ValueError."""
    if n < 0 or n > MAX_SPOKEN_NUMBER:
        raise ValueError(f"number out of range 0..{MAX_SPOKEN_NUMBER}: {n}")
    if n < 20:
        return _ONES[n]
    if n < 100:
        tens, unit = divmod(n, 10)
        return _TENS[tens] if unit == 0 else f"{_ONES[unit]} و{_TENS[tens]}"
    if n < 1000:
        hundreds, rest = divmod(n, 100)
        return _HUNDREDS[hundreds] if rest == 0 else f"{_HUNDREDS[hundreds]} و{number_to_words(rest)}"
    thousands, rest = divmod(n, 1000)
    head = _THOUSANDS.get(thousands) or f"{number_to_words(thousands)} ألف"
    return head if rest == 0 else f"{head} و{number_to_words(rest)}"


def _spell_match(match: re.Match[str]) -> str:
    digits = match.group(0)
    if len(digits) > 1 and digits.startswith("0") or int(digits) > MAX_SPOKEN_NUMBER:
        return " ".join(_ONES[int(d)] for d in digits)  # read digit by digit
    return number_to_words(int(digits))


def numbers_to_words(text: str) -> str:
    """Replace every digit sequence (ASCII or Arabic-Indic) with spoken Egyptian words."""
    return _NUMBER_RE.sub(_spell_match, text.translate(_DIGITS))


def load_pronunciation(path: Path | str | None) -> dict[str, str]:
    """Load the pronunciation dictionary (word -> replacement). Missing file means empty."""
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    data = json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{p} must contain a JSON object of word -> replacement")
    return {str(k): str(v) for k, v in data.items()}


def apply_pronunciation(text: str, dictionary: Mapping[str, str]) -> str:
    """Replace whole words using the dictionary (longest entries first)."""
    for word in sorted(dictionary, key=len, reverse=True):
        if not word:
            continue
        text = re.sub(rf"(?<!\w){re.escape(word)}(?!\w)", lambda _m, r=dictionary[word]: r, text)
    return text


def split_long(text: str, max_words: int = 15) -> list[str]:
    """Split text into chunks of at most ``max_words`` words.

    Splits on sentence punctuation first, then on commas, then by raw word count.
    """
    if max_words < 1:
        raise ValueError("max_words must be >= 1")
    chunks: list[str] = []
    for sentence in (s.strip() for s in _CHUNK_RE.findall(text)):
        if not sentence:
            continue
        if len(sentence.split()) <= max_words:
            chunks.append(sentence)
            continue
        pieces = [p.strip() for p in re.split(r"(?<=[،,؛;])\s*", sentence) if p.strip()]
        current: list[str] = []
        for piece in pieces:
            words = piece.split()
            if current and len(current) + len(words) > max_words:
                chunks.append(" ".join(current))
                current = []
            while len(words) > max_words:  # last resort: hard split
                chunks.append(" ".join(words[:max_words]))
                words = words[max_words:]
            current.extend(words)
        if current:
            chunks.append(" ".join(current))
    return chunks


def prepare_text(text: str, pronunciation: Optional[Mapping[str, str]] = None,
                 max_words: int = 15) -> list[str]:
    """Full preprocessing: clean, spell numbers, pronunciation dictionary, split."""
    t = clean_text(text)
    t = numbers_to_words(t)
    t = apply_pronunciation(t, pronunciation or {})
    return split_long(t, max_words)
