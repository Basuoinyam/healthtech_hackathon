"""Hash-based cache for synthesized audio (spec section 4, step 5)."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any, Optional

import numpy as np
import soundfile as sf


class AudioCache:
    """Stores raw engine output as float32 WAV files keyed by a content hash."""

    def __init__(self, directory: Path | str, enabled: bool = True) -> None:
        self.directory = Path(directory)
        self.enabled = enabled
        self.hits = 0
        self.misses = 0

    @staticmethod
    def make_key(text: str, voice: Optional[str], engine: str, params: dict[str, Any]) -> str:
        """Hash of (text + voice + engine/model + parameters)."""
        payload = json.dumps({"text": text, "voice": voice, "engine": engine, "params": params},
                             sort_keys=True, ensure_ascii=False, default=str)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _path(self, key: str) -> Path:
        return self.directory / f"{key}.wav"

    def get(self, key: str) -> Optional[tuple[np.ndarray, int]]:
        """Return (audio, sample_rate) or None. A corrupt file counts as a miss."""
        if not self.enabled:
            return None
        p = self._path(key)
        if p.exists():
            try:
                audio, sr = sf.read(str(p), dtype="float32")
                self.hits += 1
                return audio, int(sr)
            except Exception:
                pass
        self.misses += 1
        return None

    def put(self, key: str, audio: np.ndarray, sr: int) -> None:
        """Store audio atomically. Failures are ignored (the cache is best-effort)."""
        if not self.enabled:
            return
        try:
            self.directory.mkdir(parents=True, exist_ok=True)
            tmp = self._path(key).with_suffix(".tmp.wav")
            sf.write(str(tmp), audio, sr, subtype="FLOAT")
            os.replace(tmp, self._path(key))
        except Exception:
            pass
