"""CLI entry point for egyptian-care-voice."""
from __future__ import annotations

import json
import random
from pathlib import Path

import typer
from pydantic import ValidationError

from core.personalize import personalize_script
from core.safety import get_validator
from core.schema import Mood, Patient, Phase, Script, format_errors_ar
from core.selector import load_config, resolve_path, select
from engines import EngineError, get_engine

app = typer.Typer(help="Egyptian care voice robot (TTS)", no_args_is_help=True)


def load_script(path: Path) -> Script:
    """Load and validate a script file. Raises typer.Exit(1) on failure."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return Script.model_validate(data)
    except FileNotFoundError:
        typer.echo(f"File not found: {path}", err=True)
    except json.JSONDecodeError as exc:
        typer.echo(f"Invalid JSON: {exc}", err=True)
        typer.echo("ملف الـ JSON مش سليم", err=True)
    except ValidationError as exc:
        typer.echo(f"Validation failed for {path}:", err=True)
        for line in format_errors_ar(exc):
            typer.echo(f"  - {line}", err=True)
    raise typer.Exit(1)


@app.command()
def validate(script_path: Path) -> None:
    """Validate a script JSON file."""
    script = load_script(script_path)
    n = sum(len(m.segments) for m in script.messages)
    typer.echo(f"OK: {len(script.messages)} message(s), {n} segment(s).")


@app.command()
def generate(
    script_path: Path,
    engine: str = typer.Option(None, "--engine", help="Engine name (default: from config.yaml)."),
    out: Path = typer.Option(Path("outputs/out.mp3"), "--out", help="Output .mp3 or .wav file."),
    voice: str = typer.Option(None, "--voice", help="Force a voice for every segment."),
    no_cache: bool = typer.Option(False, "--no-cache", help="Disable the audio cache."),
) -> None:
    """Generate an audio file and timestamps.json from a script."""
    from core.audio import ExportError
    from core.cache import AudioCache
    from core.pipeline import SafetyRejection, run_pipeline

    script = load_script(script_path)
    cfg = load_config()
    name = engine or cfg.get("default_engine", "voicetut")
    try:
        eng = get_engine(name, cfg)
        cache = AudioCache(resolve_path(cfg.get("cache_dir", ".cache")) / "audio", enabled=not no_cache)
        res = run_pipeline(script, eng, out, config=cfg, cache=cache, voice=voice)
    except SafetyRejection as exc:
        typer.echo("Script rejected by the safety validator:", err=True)
        for line in exc.result.reasons("ar", include_warnings=False):
            typer.echo(f"  - {line}", err=True)
        raise typer.Exit(1)
    except (EngineError, ExportError) as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    for w in res.warnings:
        typer.echo(f"Warning: {w}", err=True)
    typer.echo(f"Audio: {res.audio_path} ({res.duration_ms} ms)")
    typer.echo(f"Timestamps: {res.timestamps_path}")
    typer.echo(f"Cache: {res.cache_hits} hit(s), {res.cache_misses} miss(es)")


def _load_patient(path: Path) -> Patient:
    try:
        return Patient.model_validate(json.loads(path.read_text(encoding="utf-8")))
    except FileNotFoundError:
        typer.echo(f"Patient file not found: {path}", err=True)
    except json.JSONDecodeError as exc:
        typer.echo(f"Invalid JSON in {path}: {exc}", err=True)
    except ValidationError as exc:
        typer.echo(f"Invalid patient file {path}:", err=True)
        for line in format_errors_ar(exc):
            typer.echo(f"  - {line}", err=True)
    raise typer.Exit(1)


@app.command()
def speak(
    phase: str = typer.Option(..., help="morning_checkin | before_session | during_session | after_session | bad_day | milestone | night"),
    mood: str = typer.Option("", help="good | tired | anxious | sad | pain"),
    patient: Path = Path("examples/patient.json"),
    event_text: str = typer.Option("", help="Optional patient text, checked for emergency words"),
    seed: int = typer.Option(-1, help="Fixed random seed (for reproducible output)"),
    memory_file: Path = typer.Option(None, help="Recent-phrases memory file (default from config.yaml)"),
    no_memory: bool = typer.Option(False, "--no-memory", help="Do not read or write the memory file"),
    alerts_log: Path = typer.Option(None, help="Alerts log file (default from config.yaml)"),
    personalized: bool = typer.Option(False, "--personalized", help="Resolve {name} and gender forms in the output"),
) -> None:
    """Pick a message by phase/mood and print the script JSON.

    Pain or an emergency phrase prints the escalation script (exit code 0)
    and writes an alert to the alerts log.
    """
    try:
        Phase(phase)
        if mood:
            Mood(mood)
    except ValueError:
        typer.echo(f"Unknown phase or mood. Phases: {[p.value for p in Phase]}; "
                   f"moods: {[m.value for m in Mood]}", err=True)
        raise typer.Exit(1)
    cfg = load_config()
    pat = _load_patient(patient)
    mem = None if no_memory else resolve_path(memory_file or cfg.get("recent_memory_file", ".cache/recent_phrases.json"))
    log = resolve_path(alerts_log or cfg.get("alerts_log", "logs/alerts.log"))
    sel = select(pat, phase, mood or None, event_text or None, config=cfg,
                 rng=random.Random(seed) if seed >= 0 else None,
                 memory_path=mem, alerts_log=log)
    script = Script.model_validate(sel.script)  # the output must always be a valid script
    if personalized:
        script = personalize_script(script)
        result = get_validator().validate_script(script)
        if not result.ok:
            for reason in result.reasons():
                typer.echo(f"Safety check failed: {reason}", err=True)
            raise typer.Exit(1)
    typer.echo(json.dumps(script.model_dump(mode="json", exclude_none=True), ensure_ascii=False, indent=2))


@app.command()
def voices(engine: str = typer.Option("voicetut", "--engine", help="Engine name (voicetut, cairo or mock)")) -> None:
    """List voices provided by a speech engine."""
    try:
        names = get_engine(engine, load_config()).list_voices()
    except EngineError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    for name in names:
        typer.echo(name)


if __name__ == "__main__":
    app()
