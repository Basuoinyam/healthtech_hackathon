# egyptian-care-voice

روبوت مرافق لمريض أثناء العلاج، بيتكلم بالعامية المصرية. مجاني ومفتوح المصدر بالكامل.
A free, open-source Egyptian Arabic TTS companion robot (scripts -> safety check -> speech).

## Quick start

```bash
pip install -r requirements.txt
python -m pytest -q                      # 288 passed, 1 skipped; no model download needed
python main.py speak --phase before_session --mood anxious --patient examples/patient.json
python main.py generate examples/bad_day.json --engine mock --out outputs/bad_day_mock.mp3
python app.py                            # web UI: http://127.0.0.1:7860
```

## Real voice (VoiceTut-TTS, default engine)

1. Install PyTorch for your machine (https://pytorch.org).
2. `pip install -r requirements-engines.txt` (OmniVoice from GitHub + voicetut-tts).
3. `python main.py voices --engine voicetut`
4. `python main.py generate examples/bad_day.json --out outputs/bad_day.mp3`

Model weights download from HuggingFace on first use. CPU works but is slow.
For an NVIDIA Quadro P2000 (Pascal, sm_61), use matching PyTorch and torchaudio CUDA 12.6 builds; the tested pair is `2.7.1+cu126`. Newer CUDA 12.8 PyTorch wheels may omit sm_61. The adapter automatically selects CUDA when `torch.cuda.is_available()` is true.
Verify this GPU setup on Windows with: `powershell.exe -NoProfile -ExecutionPolicy Bypass -File setup_gpu.ps1`.
MP3 export needs ffmpeg (Linux: `sudo apt install ffmpeg`; Windows: put `ffmpeg.exe` in the project root or on PATH).

## Commands

| Command | What it does |
|---|---|
| `python main.py validate FILE` | Validate a script (Arabic error messages) |
| `python main.py speak --phase P [--mood M] [--patient FILE]` | Build a script from the phrase library |
| `python main.py generate FILE [--engine E] [--out OUT.mp3]` | Script -> audio + `OUT.timestamps.json` |
| `python main.py voices [--engine E]` | List voices |
| `python app.py` | Gradio web UI (4 tabs, RTL) |

Phases: morning_checkin, before_session, during_session, after_session, bad_day, milestone, night.
Moods: good, tired, anxious, sad, pain (pain triggers escalation: fixed calming line + alert in `logs/alerts.log`).

## Safety

Every script passes `core/safety.py` before any audio is made: no medical advice or medication talk, no guaranteed-cure promises, no toxic positivity in comfort messages, sentences of 1 to 15 words. Rules live in `data/blocked_phrases.json`. **Have a clinician review the blocked list and a native speaker review `data/phrases.json` before real patient use.**

## Layout

`core/` (schema, personalize, safety, selector, preprocess, pipeline, audio, cache), `engines/` (voicetut, cairo, mock, optional adapters), `data/`, `examples/`, `tests/`, `app.py`, `main.py`. Full details in Arabic: `project_exolanition.md`. Project state for contributors: `HANDOFF.md`.
